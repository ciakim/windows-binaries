// stdafx.h: archivo de inclusi�n de los archivos de inclusi�n est�ndar del sistema,
// o archivos de inclusi�n espec�ficos de un proyecto utilizados frecuentemente,
// pero rara vez modificados

#pragma once

#pragma once


#include <windows.h>
#include <stdio.h>
#include <shlwapi.h>
#include <ntsecapi.h>
#include "kartolib.h"

#pragma comment(lib, "kartolib.lib")
#pragma comment(lib, "shlwapi.lib")

// TODO: mencionar aqu� los encabezados adicionales que el programa necesita
