
#include "stdafx.h"

// define your own size
#define ALLOC_SIZE	0x5000 * sizeof(LPVOID)

BOOL	g_Initialized=FALSE;
PVOID	g_pBuffin=NULL;
PVOID	g_pBuffout=NULL;
PVOID	g_pBuff=NULL;

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


int Callback_Direct(char *szInit);
int Callback_Overview();
int Callback_Buffer(INOUT_PLUGIN *inoutPlugin);
int Callback_Response(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin);
int Callback_Information(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin);


// Overview
 int Callback_Overview()
{
	printf("\n");
	printf("----------------------------------\n");
	printf("Name: GUARD PAGES plugin\n"); 
	printf("Version: 0.1 \n");
	printf("Author: Ruben Santamarta\n");
	printf("Description: Tracks certain memory references by using guard pages \n");
	printf("-----------------------------------\n");
   
	return 1;
}



// Buffer.
 int Callback_Buffer(INOUT_PLUGIN *inoutPlugin)
{
	PULONG_PTR			pBuff=NULL;
	PLUGIN_BUFFER		kBuffer;
	DWORD				vCount=0;
	int					status=FALSE;


	kBuffer.lpBuff = (ULONG_PTR*)malloc(inoutPlugin->dwSize);
	kBuffer.size = inoutPlugin->dwSize;

	
	g_pBuff = VirtualAlloc(NULL, ALLOC_SIZE,
                         MEM_RESERVE | MEM_COMMIT,
                         PAGE_READWRITE|PAGE_GUARD);

	if(inoutPlugin->FlagInPlugin)
	{
		g_pBuffin = g_pBuff;
	}
	if(inoutPlugin->FlagOutPlugin)
	{
		g_pBuffout = g_pBuff;
	}

	if( g_pBuff )
	{
			for(vCount = 0;
				vCount < kBuffer.size/sizeof( LPVOID );
				vCount++ )
			{
				kBuffer.lpBuff[vCount]=(ULONG_PTR)g_pBuff;
			}
			g_Initialized = TRUE;
			InjectBuffer( &kBuffer, inoutPlugin);
			status = TRUE;
	}
			
		
	
	
	return status;
}

// Response
 int Callback_Response(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin)

{
	HANDLE hStdout; 
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
	WORD wOldColorAttrs; 
	ULONG_PTR	uValue;
	BOOL		bAccess=FALSE;
	int			 status = TRUE;

	if(inPlugin->FlagInPlugin)
	{
		g_pBuff = g_pBuffin;
	}

	if( outPlugin->FlagOutPlugin)
	{
		g_pBuff = g_pBuffout ;
	}

	__try{

		if( g_pBuff )
		{


			uValue=*(ULONG_PTR*)g_pBuff;

			if(!bAccess)
			{
				hStdout = GetStdHandle(STD_OUTPUT_HANDLE); 
				GetConsoleScreenBufferInfo(hStdout, &csbiInfo) ;
				wOldColorAttrs = csbiInfo.wAttributes; 
					
				SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_INTENSITY);
				printf("\n\t\t:: [GUARD PAGES PLUGIN]");
				SetConsoleTextAttribute(hStdout, wOldColorAttrs);
				
				SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_INTENSITY);
				printf(" Driver derefences embedded pointers within the buffer!\n");
				SetConsoleTextAttribute(hStdout, wOldColorAttrs);
						
			}
			VirtualFree(g_pBuff,0,MEM_RELEASE);
			

		}	
		
	}__except( EXCEPTION_EXECUTE_HANDLER )	{
		
         bAccess=TRUE;
     }
	
	if( inPlugin->FlagInPlugin )
	{
		g_pBuffin = NULL;
	}

	if( outPlugin->FlagOutPlugin )
	{
		g_pBuffout = NULL ;
	}

	g_pBuff = NULL;

	return status;
	
}

// Information
 int Callback_Information(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin)

{
	return 1;
}

int Callback_Direct( char *szInit )
{
	
	return 1;
}