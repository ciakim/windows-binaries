

#pragma once


#include <windows.h>
#include <stdio.h>
#include <ntsecapi.h>

#include "kartolib.h"

#pragma comment(lib, "kartolib.lib")
