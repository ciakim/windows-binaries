#pragma once

#include <stdio.h>
#include <windows.h>
#include <ntsecapi.h>

#include "kartolib.h"

#pragma comment(lib,"kartolib.lib")