


#include "stdafx.h"

// define your own size
#define ALLOC_SIZE	0x100 * sizeof(LPVOID)

BOOL	g_Initialized=FALSE;
PVOID	g_pKern;

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


int Callback_Direct(char *szInit);
int Callback_Overview();
int Callback_Buffer(INOUT_PLUGIN *inoutPlugin);
int Callback_Response(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin);
int Callback_Information(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin);


// Overview
 int Callback_Overview()
{
	printf("\n");
	printf("----------------------------------\n");
	printf("Name: Kernel Embedded Pointers\n"); 
	printf("Version: 0.1 \n");
	printf("Author: Ruben Santamarta\n");
	printf("Description: Kernel Embedded pointers verification\n");
	printf("-----------------------------------\n");
   
	return 1;
}



// Buffer.
 int Callback_Buffer(INOUT_PLUGIN *inoutPlugin)
{
	PULONG_PTR			pBuff=NULL,pKbuff=NULL;

	PLUGIN_BUFFER		kBuffer;
	DWORD				vCount=0;
	int					status=FALSE;
	HANDLE				hKdevice;
	KARTO_DIRS			kDirs;
	char				szKdriver[MAX_PATH];
	

	hKdevice = OpenKDevice();

	if (hKdevice == INVALID_HANDLE_VALUE) 
	{
		InitializePaths(&kDirs);
		
		sprintf(szKdriver,
				"%s\\kartoffel.sys",
				kDirs.KARTO_PATH);
	
		if( !LoadDriver( szKdriver,"KartoffelDrv") )
		{
			printf("[!] Unable to load kartoffel.sys\n");
			exit(0);
		}
			
		hKdevice = OpenKDevice();
			
		if( hKdevice ==INVALID_HANDLE_VALUE ) return FALSE;
		CloseHandle(hKdevice);
	}

	kBuffer.lpBuff = (ULONG_PTR*)malloc(inoutPlugin->dwSize);
	kBuffer.size = inoutPlugin->dwSize;
	g_pKern = kalloc(ALLOC_SIZE,0);
		
	if( g_pKern )
	{
		kread( &pKbuff, g_pKern, 0, TRUE);
			
		for(vCount = 0;
			vCount < ALLOC_SIZE/sizeof( LPVOID );
			vCount++)
			{
				pKbuff[vCount]=(ULONG_PTR)g_pKern;
			}
			
			kwrite(g_pKern,pKbuff,0);

			for(vCount = 0;
				vCount < kBuffer.size/sizeof( LPVOID );
				vCount++ )
			{
				kBuffer.lpBuff[vCount]=(ULONG_PTR)g_pKern;
			}
			g_Initialized = TRUE;
			InjectBuffer( &kBuffer, inoutPlugin);
			status = TRUE;
	}
			
		
	
	
	return status;
}

// Response
 int Callback_Response(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin)

{
	HANDLE hStdout; 
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
	WORD wOldColorAttrs; 
	PULONG_PTR	 pKbuff = NULL;
	DWORD		 vCount;
	int			 status = FALSE;

	if( kread(&pKbuff,g_pKern,0,TRUE) )
	{
	
		for(vCount=0;
			vCount<ALLOC_SIZE/sizeof(LPVOID);
			vCount++)
		{
			if( pKbuff[vCount] != (ULONG_PTR)g_pKern)
			{ 
				hStdout = GetStdHandle(STD_OUTPUT_HANDLE); 
				GetConsoleScreenBufferInfo(hStdout, &csbiInfo) ;
				wOldColorAttrs = csbiInfo.wAttributes; 
				
				SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_INTENSITY);
				printf("\n\t\t:: [EMBEDDED POINTERS PLUGIN]");
				SetConsoleTextAttribute(hStdout, wOldColorAttrs);
				
				SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_INTENSITY);
				printf(" Arbitrary Kernel Memory Overwrite Found!\n");
				SetConsoleTextAttribute(hStdout, wOldColorAttrs);
				
				status = TRUE;
			}
		}
	}
	return status;
	
}

// Information
 int Callback_Information(INOUT_PLUGIN *inPlugin,INOUT_PLUGIN *outPlugin)

{
	return 1;
}

int Callback_Direct( char *szInit )
{
	printf("\n\n:: Freeing memory\n");
	kglobalfree();
	
	return 1;
}