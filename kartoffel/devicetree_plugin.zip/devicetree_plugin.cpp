
#include "stdafx.h"
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    return TRUE;
}


 int Callback_Overview()
{
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
	HANDLE			hStdout; 
	WORD			wOldColorAttrs; 
	
	hStdout = GetStdHandle(STD_OUTPUT_HANDLE); 
	GetConsoleScreenBufferInfo(hStdout, &csbiInfo) ;
	wOldColorAttrs = csbiInfo.wAttributes; 
	
	printf("\n");
	SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_INTENSITY);				
	printf("=====================================================	\n");
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);
	
	SetConsoleTextAttribute(hStdout, FOREGROUND_GREEN|FOREGROUND_INTENSITY);	
	printf("      DRIVER_OBJECT-based Device Tree  K-Plugin		\n");
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);
	
	SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_INTENSITY);				
	printf("=====================================================	\n");
	SetConsoleTextAttribute(hStdout, wOldColorAttrs);
	printf("\n+ K-plugin by: \n");
	printf("  Ruben Santamarta (reversemode.com)\n");
	return 1;
}

int Callback_Direct( char *lpInitStr )
{
	
	CONSOLE_SCREEN_BUFFER_INFO csbiInfo;
	HANDLE			hStdout; 
	WORD			wOldColorAttrs; 
	KARTO_DIRS		kDirs;
	WCHAR			**lpDevices = NULL;
	WCHAR			**lpDrivers = NULL;
	LPVOID			pKern=0;
	HANDLE			hKdevice;
	char			szKdriver[MAX_PATH];
	DWORD			dwNum,dwNumDrv,i,b,dwStatus,len;
	DRIVER_OBJECT	drvObj;
	DEVICE_OBJECT	devObj;
	WCHAR			*wcBuff;
	BOOL			bFound=FALSE;
	int				status=0;

	

	
	Callback_Overview();
	
	
	if(!lpInitStr) 
	{
		printf("\n Usage: > kartoffel -D devicetree_plugin,DriverName\n");
		return FALSE;
	}
	
	len = strlen(lpInitStr)+1;
	wcBuff = ( WCHAR* ) calloc ( len,sizeof(WCHAR) ) ; 

	MultiByteToWideChar( CP_ACP,
						 NULL, 
						 lpInitStr, 
						 len ,
						 wcBuff, 
						 len*sizeof(WCHAR) );

	hKdevice = OpenKDevice();

	if (hKdevice == INVALID_HANDLE_VALUE) 
	{
		InitializePaths(&kDirs);
	
		sprintf(szKdriver,
				"%s\\kartoffel.sys",
				kDirs.KARTO_PATH);

		printf("\n\n[+] Kartoffel.sys not detected. Loading %s\n",szKdriver);
		if( !LoadDriver( szKdriver,"KartoffelDrv") )
		{
			printf("[!] Unable to load kartoffel.sys\n");
			return FALSE;
		}
		
		hKdevice = OpenKDevice();
		
		if( hKdevice == INVALID_HANDLE_VALUE ) return FALSE;
	}
	
	dwNum = EnumDevices ( ( WCHAR** )&lpDevices );
	dwNumDrv = EnumDrivers ( ( WCHAR** )&lpDrivers );

	printf("\n[+] Searching %ws...",wcBuff);

	for( i = 0; i< dwNumDrv; i++ )
	{
		if( StrStrIW( lpDrivers[i], wcBuff ) )
		{
			printf("Found!\n\n");
			bFound = TRUE;
			break;
		}
	}

    if( bFound )
	{
		printf("__________________________________________\n\n");
		
		hStdout = GetStdHandle(STD_OUTPUT_HANDLE); 
		GetConsoleScreenBufferInfo(hStdout, &csbiInfo) ;
		wOldColorAttrs = csbiInfo.wAttributes; 
		SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE|FOREGROUND_INTENSITY);				
		printf("::_____ + %ws\n",lpDrivers[i]);
		SetConsoleTextAttribute(hStdout, wOldColorAttrs);

		
		for( b = 0; b< dwNum; b++)
		{
				if( GetDriverObjectByName ( lpDevices[b], &drvObj ) )	
				{
					if(!wcscmp(drvObj.DriverName.Buffer,lpDrivers[i]))
					{
						SetConsoleTextAttribute(hStdout, FOREGROUND_RED|FOREGROUND_INTENSITY);
						if(!status) printf("\t|\n");
						printf("\t|->%ws\n",lpDevices[b]);
						SetConsoleTextAttribute(hStdout, wOldColorAttrs);
						status=TRUE;
					}
				}
		}
		
	}
	if(!status) printf("\n[+] Nothing found\n");
	return status;
}