
#pragma once


#include <windows.h>
#include <stdio.h>
#include <ntsecapi.h>
#include <shlwapi.h>
#include "kartolib.h"
#include "ring0.h"

#pragma comment(lib, "kartolib.lib")
#pragma comment(lib, "shlwapi.lib")