


/* Insider -- Win32 reverse backdoor */



#include "insider.h"

#define DIRSEP         '\\'
#define ISDIRSEP(c)    ((c) == '\\' || (c) == '/')
#define ISABSPATH(s)   (((s)[0] && (s)[1] == ':' && ISDIRSEP((s)[2])))
#define ISROOTEDPATH(s) (ISDIRSEP((s)[0]) || ISABSPATH(s))


char *
getcd(char *newcd) {
	int len;
	char *ret;

	/* Absolute directory */
	if (!strncmp(newcd + 1, ":\\", 2)) {
		if (!(ret = strdup(newcd)))
			exit (1);
		return (ret);
	}

	/* Relative directory */

	/* Get space for return path */
	len = strlen(cdir) + strlen(newcd) + 2;
	if (!(ret = (char *)malloc(len)))
		exit (1);
	memset(ret, 0, len);

	/* Add relative path to current path and simplify */
	_snprintf(ret, len, "%s\\%s", cdir, newcd);
	simplify_path(ret);

	return (ret);
}


/* This routine is from pdksh sources (public domain) */

/*
 * Simplify pathnames containing "." and ".." entries.
 * ie, simplify_path("/a/b/c/./../d/..") returns "/a/b"
 */

void
simplify_path(char *path) {
	int	isrooted;
        char    *cur;
        char    *t;
        char    *very_start = path;
        char    *start;

        if (!*path)
                return;

	if ((isrooted = ISROOTEDPATH(path)))
                very_start++;

        if (path[0] && path[1] == ':')  /* skip a: */
                very_start += 2;

       /* preserve leading double-slash on pathnames (for UNC paths) */
       if (path[0] && ISDIRSEP(path[0]) && path[1] && ISDIRSEP(path[1]))
               very_start++;

        for (cur = t = start = very_start; ; ) {
                /* treat multiple '/'s as one '/' */
                while (ISDIRSEP(*t))
                        t++;

                if (*t == '\0') {
                        if (cur == path)
                                /* convert empty path to dot */
                                *cur++ = '.';
                        *cur = '\0';
                        break;
                }

                if (t[0] == '.') {
                        if (!t[1] || ISDIRSEP(t[1])) {
                                t += 1;
                                continue;
                        } else if (t[1] == '.' && (!t[2] || ISDIRSEP(t[2]))) {
                                if (!isrooted && cur == start) {
                                        if (cur != very_start)
                                                *cur++ = DIRSEP;
                                        *cur++ = '.';
                                        *cur++ = '.';
                                        start = cur;
                                } else if (cur != start)
                                        while (--cur > start && !ISDIRSEP(*cur))
                                                ;
                                t += 2;
                                continue;
                        }
                }
                if (cur != very_start)
                        *cur++ = DIRSEP;

                /* find/copy next component of pathname */
                while (*t && !ISDIRSEP(*t))
                        *cur++ = *t++;
        }
}
